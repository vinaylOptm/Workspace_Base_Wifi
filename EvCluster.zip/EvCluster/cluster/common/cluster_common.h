#ifndef CLUSTER_COMMON_H_
#define CLUSTER_COMMON_H_


#ifdef __cplusplus
 extern "C" {
#endif

/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt. Ltd - All Rights Reserved	   	   *
 *																			   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_common.h
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023
 *  Description :  				 										 	   *
 *                               						                       *
 *																			   *
 *-----------------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "timers.h"
#include <stdbool.h>

#define  BCU_OK    0
#define  BCU_NOK   1

#define  EXTERNAL_SW     0
#define  NAVIGATION_SW   1

#define  VEHICLE_CHARGESTATE_INFO  	   4
#define  VEHICLE_DTC_INFO              3
#define  VEHICLE_SEPC_INFO_MEMSEC      2
#define  CLUSTER_INFO_MEMSEC1          1
#define  CLUSTER_INFO_MEMSEC0          0

typedef enum
{
	 eModule_None		= 0,	
	 eModule_Bt			= 1 << 0,
	 eModule_Can		= 1 << 1,
	 eModule_Rtc    	= 1 << 2,
	 eModule_Switch   	= 1 << 3,
	 eModule_BackLight  = 1 << 4,
	 eModule_Flash      = 1 << 5,
	 eModule_Uds        = 1 << 6,
	 eModule_Adc        = 1 << 7,
	 eModule_Wifi		= 1 << 8,
}Cluster_Modules_t;

typedef enum
{
    eEvent_None				= 0,
	eEvent_Motor			= 1,
	eEvent_Battery			= 2,
	eEvent_Charge			= 3,
	eEvent_ChargeAlert   	= 4,
	eEvent_Time             = 5,
	eEvent_DriveMode		= 6,
	eEvent_NavSwitch		= 7,
	eEvent_HwIndicator		= 8,
	eEvent_Call				= 9,
	eEvent_DeviceStatus		= 10,
	eEvent_TurnByTurnNav	= 11,
	eEvent_Message			= 12,
	eEvent_BTMessage        = 13,
	eEvent_Alert			= 14,
	eEvent_Fault			= 15,
	eEvent_Indicator		= 16,
	eEvent_Standby			= 17,
	eEvent_Status			= 18,
	eEvent_DeviceVersion    = 19,
	eEvent_Image			= 20,
// Custom
	eEvent_Status0     		= 21,
	eEvent_Status1     		= 22,
	eEvent_Adc				= 23,
	eEvent_Max				= 24,
}eClusterEvents_t;

typedef enum
{
	eSecurityAccess			        = 0x27,
	eDiagnosticSessionControl       = 0x10,
	eProgrammingSession             = 0x02,
	eKeyValue			            = 0x1010,
	eRequestSeed		            = 0x01,
	eSendKey		                = 0x02,
	eFlashMode    					= 0x11,
	eRtcSetTime   					= 0x12,
	eFactoryReset 					= 0x13,
	eBacklightSet 					= 0x14,
	eHardwareStatus 				= 0x15,
	eReadSwHwVersion 				= 0x16,
	eWriteDataByIdentifier          = 0x2E,
	eSlNoIdentifier                 = 0x1F,
	eVINIdentifier                  = 0x2F,
	eDateIdentifier				    = 0x3F,
	eReadDataByIdentifier           = 0x22,
	eReadDTCInformation             = 0x19,
	eReportDTCByStatusMask          = 0x02,
	eClearDiagnosticInformation     = 0x14,
}eClusterUdsServices_t;

typedef enum
{
	eSubFunNotSupported		        = 0X12,
	eIncorrectMesLenOrInavlidFormat	= 0x13,
	eConditiosNotCorrect			= 0x22,
	eReqSeqError					= 0x24,
	eReqOutOFRange					= 0x31,
	eInvalidKey						= 0x35,
	eExceededNumOfAttempts			= 0x36,
	eReqTimeDelayNotExp				= 0x37,
}eClusterUdsNRCs_t;

typedef enum
{
	eDeviceNone   = 0,
	eDeviceBt 	  = 1,
	eDeviceWifi   = 2,
	eDeviceLTE    = 3,
    eDeviceGPS    = 4,
	eDeviceMax    = 5
}eDevice_t;

typedef enum
{
	eCanFault 	 	= 1 << 0,
	eRtcFault 		= 1 << 1,
	eSwitchFault    = 1 << 2,
    eBleFault       = 1 << 3,
	eWifiFault      = 1 << 4,
}eClusterDTCInfo_t;

typedef enum
{
	eInput1  = 0x01,
	eInput2  = 0x02,
	eInput3  = 0x03,
	eInput4  = 0x04,
	eInput5  = 0x05,
	eInput6  = 0x06,
	eInput7  = 0x07,
	eInput8  = 0x08,
	eInput9  = 0x09,
	eInput10 = 0x10,
	eInputs_All = 0x11,
}eHwSubid_t;

typedef enum
{
	eGearmode_None     = 0,
    eGearmode_Neutral  = 1,
    eGearmode_Drive    = 2,
	eGearmode_Reverse  = 3,
	eGearmode_Parking  = 4,
    eGearmode_Invalid  = 5,
}eGearmode_t;

typedef enum
{
	eDriveMode_None     = 0,
    eDriveMode_Eco    	= 1,
	eDriveMode_Sport    = 2,
    eDriveMode_Power  	= 3,
    eDriveMode_Invalid  = 4,
}eDriveode_t;

typedef enum
{
#if(CLUSTER_KEYIGNITION_SUPPORTED == 1)
	eGpioKey0		= 12U, //evk ignition via GPIO
#else
	eGpioKey0		= 12U, //mapped to wakeup
#endif
	eGpioKey1       = 3U,
	eGpioKey2		= 4U,
	eGpioKey3       = 5U,
	eGpioKey4		= 6U,
	eGpioKey5       = 7U,
	eGpioKey6       = 8U,
	eGpioKey7       = 9U,
	eGpioKey8       = 10U,
	eGpioKey9       = 11U,
}eGPIOKey_t;

typedef enum
{
	eClusterKey1    = 3U,
	eClusterKey2    = 4U,
	eClusterKey3    = 5U,
}eClusterKey_t;

typedef enum
{
	eRtc_Init     = 1,
	eRtc_State    = 2,
	eRtc_Param    = 3,
	eRtc_Save     = 4,
}eRtcSet_t;

typedef enum
{
	eKey_Left     = 1,
	eKey_Ok   	  = 1 << 1,
	eKey_Right    = 1 << 2,
}eSwitch_t;

typedef enum
{
	eSpeedInfo 	 	 =   1,
	eBrightnessInfo  =   2,
	eBLEStatusInfo   =   3,
	eWifiStatusInfo	 =   4,
	eClusterVersInfo =   5,
	eResetInfo       =   6,
	eProductInfo     =   7,
	eDTCInfo         =   8,
	eResetTrip       =   9,
	eSetOdo		     =   10,
} eSystemInfo_t;

typedef struct
{
	uint32_t iId;
	uint32_t iMode;
}sCanConfig_t;

typedef struct
{
	bool bRefresh;
	bool bInput1;
	bool bInput2;
	bool bInput3;
	bool bInput4;
	bool bInput5;
	bool bInput6;
	bool bInput7;
	bool bInput8;
	bool bInput9;
	bool bInput10;
	bool bInput11;
}sHwInputs_t;

typedef struct
{
	uint32_t iTextCode;
}sTextInfo_t;

 typedef struct
 {
	 uint8_t iVal;//refer eSwitch_t
 }sNavSwitch_t;

typedef struct
{
    int32_t iCanId;
    uint32_t iDataLen;
    uint8_t iFormat; //0->Std, 1 ->Extended
    uint8_t sData[8];
}sCanMessage_t;

typedef struct
{
	bool	 bRegen;
    uint32_t iSpeed;
    uint32_t iOdo;
    uint32_t iTrip;
    uint32_t iRange;
    uint32_t iRpm;
    uint32_t iPower;
    uint32_t iTemp;
}sMotorInfo_t;

typedef struct
{
	bool	 bEnable;
	uint8_t* pImage;
    uint32_t iWidth;
    uint32_t iHeight;
}sImageInfo_t;

typedef struct
{
	int32_t	iDriveVal;
	int32_t iGearVal;
}sDriveMode_t;

typedef struct
{
	bool bType;
	bool bGunlock;
	uint32_t iStatus;
	uint32_t iTime;
	uint32_t iEnergyCon;
}sChargeInfo_t;

typedef enum
{
	eChargestate_Idle     	= 0,
	eChargestate_Charging 	= 1,
    eChargestate_Discharge  = 2,
	eChargestate_Complete	= 3,
	eChargestate_Connected	= 4,
	eChargestate_Failed		= 5,
}eChargestate_t;

typedef struct
{
    uint32_t iSoc;
    uint32_t iVoltage;
    uint32_t iCurrent;
    uint32_t iTemp;
    uint32_t iRange;
    uint32_t iPower;
}sBatteryInfo_t;

typedef struct
{
	uint8_t iDayId;
	uint8_t iDay;
	uint8_t iMonth;
	uint8_t iYear;
	uint8_t iHour;
	uint8_t iMinute;
	uint8_t iSecond;
	uint8_t iIsEdit;
	uint8_t iState;
	bool    bPM;
	bool 	bEnable;
}sTimeInfo_t;

typedef enum
 {
	 eStateNone		=  -1,
	 eStateDay    	=  0,
	 eStateMonth 	=  1,
	 eStateYear  	=  2,
	 eStateHour 	=  3,
	 eStateMinute  	=  4,
	 eStateMeridiem =  5,
	 eStateMax =  5
 }eRtcState_t;

typedef struct
{
	int32_t iId;
	int32_t iStatus;
}sDeviceStatus_t;

typedef struct
{
    int32_t iEventId;
    int8_t sData[252];
}sMessage_t;

typedef struct
{
    QueueHandle_t 		QueueId;
}sController_t;

typedef struct
{
	uint32_t	iOdoVal;
	uint32_t 	iCurTrip;
}sClusterInfo_t;

typedef struct
{
	uint32_t  iSlNum;
	char  sVin[32];
}sDeviceInfo_t;

typedef struct
{
	bool  		bEnable;
	uint32_t  	iSwVersion;
	uint32_t  	iHwVersion;
	uint32_t  	iSlNum;
	char  		sSwVer[32];
	char  		sHwVer[32];
	char  		sSlNum[32];
	char      	sVin[32];
	char      	sDate[32];
} sSystemInfo_t;

typedef enum
{
	eChargeNone   		 = 0,
	eChargeOverDue       = 1,
}eChargeAlert_t;

typedef struct
{
	uint8_t   iStatus;
	uint8_t   iSocVal;
	uint32_t  iTime;
	uint8_t   iSasStatus;
	uint32_t  iSasTime;
}sChargeAlert_t;

typedef enum
{
	eAlert_CAN      = 0x100,
	eAlert_Rtc      = 0x101,
	eAlert_Switch   = 0x102,
	eAlert_Trip    	= 0x103,
	eAlert_Custom  	= 0x104,
	eAlert_BLE		= 0x105,
	eAlert_Wifi				 = 0x107,
}eAlertId_t;

typedef enum
 {
	 eCallInComing   =  0,
	 eCallOutGoing   =  1,
	 eCallInProgress =  2,
	 eCallIdle 		 =  3,
	 eCallUnknown	 =  4
 }eCallStatus_t;

typedef struct
{
	bool bEnable;
    char sMsg[192];  // Bt data with 128 bytes
}sBtMsg_t;

typedef struct
{
    int32_t  iResp;
}sAuthenResp_t;

typedef struct
{
    int32_t  iResp;
}sCallResp_t;

typedef enum
{
	eDevData        =   1,
	eAuthenData   	=   2,
	eCallResp       =   3,
    eBtTest         =   4,
	eVehicleWarning =   5
}sMsgType;


typedef struct
{
	uint8_t  iMode;
  	char     sNum[16];
	char     sMsg[32];
}sCallInfo_t;

typedef struct
{
	uint32_t	iOddoVal;
	uint32_t 	iCurTrip;
	uint8_t  	iBleStatus;
	uint8_t    	iWifiStatus;
	uint8_t     iBrightness;
}ClusterInfo_t;

typedef struct
{
    int iDir;
    int iDist;
    char sMsg[128];
}sTbtNavInfo_t;

typedef struct
{
	eAlertId_t    iId;
	uint32_t 	iCode;
	uint8_t    iCount;
}sAlertInfo_t;

typedef enum
{
	eCAN_Working			 = 0,
	eCAN_NoData         	 = 1,
	eCAN_Error         		 = 2,
}eAlertCANCode_t;

typedef enum
{
	eRTC_Working			 = 0,
	eRTC_NotWorking          = 1,
	eRTC_NotSetOrBtryWeak    = 2,
}eAlertRTCCode_t;

typedef struct
{
    char sUrl[64];
    char sData[128];
    uint32_t iDataLen;
}sHTTPMessage_t;

typedef struct
{
	uint32_t iAdcVal1;
	uint32_t iAdcVal2;
	uint32_t iAdcVal3;
}sAdc_t;

// customer specific definations
typedef enum
 {
	eCANID_Frame1   =  0x18F0A7D0,
	eCANID_Frame2   =  0x18F1A7D0,
	eCANID_Frame3   =  0x18F2A7D0,
	eCANID_Frame4   =  0x18F3A7D0,
	
	eCANID_Internal =  0x0AD0FBEC,  // Internal
	eCANID_UDSRx    =  0x0AD0F001,  // UDS Rx
	eCANID_UDSTx    =  0x0AD0F002,  // UDS Tx
}eCANFrame_t;

typedef struct
{
	uint8_t  ifault;
}sFault_t;

typedef struct
{
  bool bLimphome;
  bool bHillhold;
  bool bMotorFault;
  bool bBatteryFault;
  bool bRegen;
  bool bAirbag;
}sStatus0_t;

#ifdef __cplusplus
}
#endif


#endif /* CLUSTER_COMMON_H_ */
