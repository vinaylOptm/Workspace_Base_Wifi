#include <hmihandler.h>
#include "fsl_debug_console.h"  //debug console.
#include "cluster_common.h"
HmiHandler::HmiHandler()
{

}

void HmiHandler::updatePlatform(int eEvent, void* pEventParam)
{

}

void HmiHandler::updateUI(int eEvent, void* pEventParam)
{
    switch ((ClusterEvents_t)(eEvent))
    {
    	case Event_Motor:
    	{
    		sMotorInfo_t  sParam = {0};
    		memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sMotorInfo_t));
    		motorInfoChanged((int)sParam.iSpeed,(int)sParam.iOdo,
    						 (int)sParam.iTrip,(int)sParam.iPower,
							 (int)sParam.iTemp);
    	}
        break;
    	case Event_Battery:
    	{
    		sBatteryInfo_t  sParam = {0};
    		memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sBatteryInfo_t));
    		battInfoChanged((int)sParam.iSoc, (int)sParam.iRange,
    						(int)sParam.iTemp,(int)sParam.iVoltage);
    	}
        break;
    	case Event_HwIndicator:
    	{
    		sHwInputs_t sParam = {0};
    		memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sHwInputs_t));
    		hwStatusChanged(sParam.bInput1,sParam.bInput2,
    						sParam.bInput3,sParam.bInput4,
							sParam.bInput5,sParam.bInput6,
							sParam.bInput7,sParam.bInput8,
							sParam.bInput9,sParam.bInput10);
    	}
        break;
    	case Event_Message:
    	{
    		sTextInfo_t  sParam = {0};
    		memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sTextInfo_t));
    		messageChanged(sParam.iTextCode);
    	}
        break;
       	case Event_NavSwitch:
		{
			sNavSwitch_t  sParam = {0};
			memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sNavSwitch_t));
			navSwitchStatusChanged(sParam.iVal);
		}
		break;

       	case Event_DeviceStatus:
		{
			sDeviceStatus_t  sParam = {0};
			memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sDeviceStatus_t));
			deviceStatusChanged(sParam.iId,sParam.iStatus);
		}
		break;

    	case Event_Time:
		{
    		sTimeInfo_t sParam = {0};
    		memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sTimeInfo_t));
    		dateTimeChanged((int)sParam.iDay,(int)sParam.iMonth,(int)sParam.iYear,
    						(int)sParam.iHour,(int)sParam.iMinute, sParam.bPM,
							(int)sParam.iIsEdit,(int)sParam.iState,sParam.bEnable);
    	}
        break;

    	case Event_Charge:
    	{
    		sChargeInfo_t  sParam = {0};
    		memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sChargeInfo_t));
    		chargeInfoChanged(sParam.bType,sParam.bGunlock,sParam.iStatus,sParam.iTime);
    	}
        break;
    	case Event_DriveMode:
    	{
    		sDriveMode_t  sParam = {0};
    		memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sDriveMode_t));
    		driveModeChanged(sParam.iDriveVal,sParam.iGearVal);
    	}
        break;

    	case Event_TurnByTurnNav:
    	{
    		sTbtNavInfo_t  sParam = {0};
    		memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sTbtNavInfo_t));
    		sDirMsg.setValue(sParam.sMsg);
    		tbtNavInfoChanged(sParam.iDir,sParam.iDist,sParam.sMsg);

    	}
    	break;
    	case Event_Call:
    	{
    		sCallInfo_t  sParam = {0};
    		memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sCallInfo_t));
    		sCallNum.setValue(sParam.sMsg);
    		callInfoChanged(sParam.iMode,sParam.sNum,sParam.sMsg);
    	}
    	break;
    	case Event_BTMessage:
    	{
    		sBtMsg_t  sParam = {0};
    		memcpy((char *)(&sParam),(char*)(pEventParam),sizeof(sBtMsg_t));
    		sBtMsg.setValue(sParam.sMsg);
    		btMessageChanged(sParam.bEnable);
    	}
    	break;
    	case Event_Alert:
		{
    		sAlertInfo_t sParam;
    		memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sAlertInfo_t));
    		alertInfoChanged((int)sParam.iId,(int)sParam.iCode);
    	}
    	break;

    	case eEvent_Status0:
		{
			sStatus0_t sParam;
    		memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sStatus0_t));
    		status0InfoChanged((int)sParam.bAirbag ,(int)sParam.bLimphome,(int)sParam.bHillhold,
    						 (int)sParam.bMotorFault,(int)sParam.bRegen,(int)sParam.bBatteryFault);
    	}
    	break;
		
    	case Event_DeviceVersion:
    	{
    		sSystemInfo_t sParam = {0};
    		memcpy((char *)(&sParam),(char *)(pEventParam),sizeof(sSystemInfo_t));
    		sSwVer.setValue(sParam.sSwVer);
    		sHwVer.setValue(sParam.sHwVer);
    		sSerialNum.setValue(sParam.sSlNum);
    		deviceVersionChanged(sParam.bEnable);
    	}
    	break;
    	default:
        break;
    }
}

void HmiEventQueue::onEvent(const HmiEvent &sEvent)
{
	HmiHandler::instance().updateUI(sEvent.command,sEvent.pData);
}

static HmiEventQueue hEventQueue;


void UI::sendToUI(int iEventVal, void* pEventParam)
{
	HmiEvent sEvent;
	sEvent.command = iEventVal;
	sEvent.pData = pEventParam;
    hEventQueue.postEvent(sEvent);

}
