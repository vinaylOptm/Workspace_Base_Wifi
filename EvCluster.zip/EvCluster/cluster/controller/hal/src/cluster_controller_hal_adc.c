/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_hal_bt.c 							   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   * 
 *                               						                       *
 *-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------*
 * Include Headers				           	                             	   *
 *-----------------------------------------------------------------------------*/
/* FreeRTOS kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "semphr.h"

/* Freescale includes. */
#include "MIMXRT1176_cm7.h"
#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "board.h"
#include "fsl_gpio.h"
#include "fsl_gpt.h"
#include "fsl_lpadc.h"
#include "cluster_controller_hal_adc.h"
#include "cluster_common.h"
#include "cluster_controller_hal_switch.h"
#include "cluster_controller_hal_config.h"

/*----------------------------------------------------------------------------* 
 * Macro ,Structure and Enum definition                   				      *
 *----------------------------------------------------------------------------*/
#define ADC_MAX_QUEUE_MSG_COUNT       10
#define ADC_MSG_QUEUE_BUFFER_SIZE     4
#define ADC_BASE                      LPADC1
#define ADC_CMDID                     1
#define ADC1_CHANNEL2                 2U
#define ADC1_CHANNEL3                 3U
#define ADC1_CHANNEL4                 4U

typedef struct
{
	ADC_Type           *base;
	int32_t 			iIsInitialised;
	QueueHandle_t       qRxMsg;
	QueueHandle_t       AdcMsgQueue;
	TaskHandle_t 		hThread;
}HalAdc_t;

/*----------------------------------------------------------------------------* 
 * Static and global variable definition	                         		  * 
 *----------------------------------------------------------------------------*/
static HalAdc_t   hAdc= {0};
volatile uint32_t g_LpadcConversionValue = 0U;
lpadc_conv_result_t mLpadc;
const uint32_t g_LpadcFullRange   = 4096U;
const uint32_t g_LpadcResultShift = 3U;
lpadc_conv_command_config_t mLpadcC;
const uint32_t lpadc[] = {ADC1_CHANNEL2, ADC1_CHANNEL3,ADC1_CHANNEL4};
/*----------------------------------------------------------------------------* 
 * Local function definition	                         				      *
 *----------------------------------------------------------------------------*/
static int32_t Adc_Configure(HalAdc_t *pHan);
static void Adc_ReceiveThread(void *arg);
static void DelayMs(uint32_t ms);
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Adc_Init(void)
{
	int32_t iRval = BCU_OK;
	if(hAdc.iIsInitialised == 0)
	{
		memset(&hAdc, 0 ,sizeof(HalAdc_t));
		iRval = Adc_Configure(&hAdc);
		if(iRval == BCU_OK )
		{
			hAdc.iIsInitialised = 1;

		}
	}
	return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Adc_DeInit(void)
{
	if(hAdc.iIsInitialised > 0)
	{
		if( &hAdc.hThread != NULL )
		{
			vTaskDelete( hAdc.hThread );
		}
		if(hAdc.AdcMsgQueue != 0)
		{
			vQueueDelete(hAdc.AdcMsgQueue);
		}
	}
	memset(&hAdc, 0, sizeof(HalAdc_t));
	return BCU_OK;
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Adc_SetReceiveQueueHandle(QueueHandle_t  hAdcQueue)
{
	int32_t iRval = BCU_OK;
	uint16_t iStackSize = 0;


	if (hAdc.iIsInitialised > 0)
	{
		hAdc.AdcMsgQueue	= hAdcQueue;
		 Cluster_Controller_Hal_Config_GetStackSize(&iStackSize);
		 iRval= xTaskCreate(Adc_ReceiveThread,
								"adc",
								iStackSize,
								&hAdc,
								configMAX_PRIORITIES - 2,
								&hAdc.hThread);
		iRval = BCU_OK;
	}
	return iRval;
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static void Adc_ReceiveThread(void *arg)
{
	HalAdc_t*   	pHan 		= (HalAdc_t*)(arg);
	char sRxBuf[ADC_MSG_QUEUE_BUFFER_SIZE] = {0};
	const TickType_t maxDelay = pdMS_TO_TICKS(2000); // 1 second in ticks
    int currentChannel = 0;
    sAdc_t adc;

	while (1)
	{
		xQueueReceive(pHan->qRxMsg, (char *)&sRxBuf[0], maxDelay);// for wait
		{
			LPADC_GetDefaultConvCommandConfig(&mLpadcC);
			mLpadcC.enableAutoChannelIncrement=true;
			mLpadcC.channelNumber = lpadc[currentChannel];
			LPADC_SetConvCommandConfig(ADC_BASE,ADC_CMDID, &mLpadcC);

			LPADC_DoSoftwareTrigger(ADC_BASE, 1U);
			while (!LPADC_GetConvResult(ADC_BASE, &mLpadc))
			{
				DelayMs(200); // Wait for conversion completion
			}

			uint32_t iId = lpadc[currentChannel]; // Assign the current channel ID
			if(iId == 2)
			{
				adc.iAdcVal1 = ((mLpadc.convValue  >> g_LpadcResultShift)); // 5026 at 9.99 and 646
			}
			else if(iId == 3)
			{
				adc.iAdcVal2 = ((mLpadc.convValue >> g_LpadcResultShift));
			}
			else
			{
				adc.iAdcVal3 = ((mLpadc.convValue >> g_LpadcResultShift));
			}

			currentChannel = (currentChannel + 1) % 3;
			if(currentChannel == 0)
			{
				xQueueSend(pHan->AdcMsgQueue, &adc, 500);
			}
		}
	}
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static int32_t Adc_Configure(HalAdc_t *pHan)
{
    int32_t iRval = BCU_OK;

    pHan->qRxMsg = xQueueCreate(ADC_MAX_QUEUE_MSG_COUNT, ADC_MSG_QUEUE_BUFFER_SIZE);

    lpadc_config_t mLpadcConfig;
    lpadc_conv_trigger_config_t mLpadcTrigger;

    // Configure LPADC1
    LPADC_GetDefaultConfig(&mLpadcConfig);
    mLpadcConfig.enableAnalogPreliminary = true;
     mLpadcConfig.referenceVoltageSource = kLPADC_ReferenceVoltageAlt1;
    LPADC_Init(ADC_BASE, &mLpadcConfig);

    LPADC_GetDefaultConvTriggerConfig(&mLpadcTrigger);
    mLpadcTrigger.targetCommandId = ADC_CMDID;
    mLpadcTrigger.enableHardwareTrigger = false;
    LPADC_SetConvTriggerConfig(ADC_BASE, 0U, &mLpadcTrigger);

    return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/

static void DelayMs(uint32_t ms)
{
#if defined(SDK_OS_FREE_RTOS)
    TickType_t tick;

    tick = ms * configTICK_RATE_HZ / 1000U;

    tick = (0U == tick) ? 1U : tick;

    vTaskDelay(tick);
#else
    while (0U != (ms--))
    {
        SDK_DelayAtLeastUs(1000U, SystemCoreClock);
    }
#endif
}
