/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_hal.c 							   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   * 
 *                               						                       *
 *-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------*
 * Include Headers				           	                             	   *
 *-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include "cluster_common.h"
#include "cluster_controller_hal.h"
#include "cluster_controller_hal_config.h"
#include "cluster_controller_hal_bt.h"
#include "cluster_controller_hal_adc.h"
#include "cluster_controller_hal_rtc.h"
#include "cluster_controller_hal_switch.h"
#include "cluster_controller_hal_can.h"
#include "cluster_controller_hal_backlight.h"
#include "cluster_controller_hal_flash.h"
#include "cluster_controller_hal_romapi.h"
#include "culster_controller_hal_display.h"

#if BLE_ENABLED
#include "cluster_controller_hal_bt.h"
#endif
/*----------------------------------------------------------------------------* 
 * Macro ,Structure and enum definition                   				      * 
 *----------------------------------------------------------------------------*/
typedef struct
{
	int32_t				iIsInitialised;
	int32_t				iModulesStatus;
} Hal_t;

/*----------------------------------------------------------------------------* 
 * Static and global variable definition	                         		  * 
 *----------------------------------------------------------------------------*/
static Hal_t hHal = {0};
 
/*----------------------------------------------------------------------------* 
 * Local function definations	                         				      * 
 *----------------------------------------------------------------------------*/
static int32_t Hal_Init_Modules(Hal_t * pHan,int32_t iModules);
static int32_t Hal_Deinit_Modules(Hal_t * pHan,int32_t iModules);


/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_Init(int32_t iModules)
{
	int32_t iRval = BCU_OK;
	if(hHal.iIsInitialised ==0)
	{
		memset(&hHal,0, sizeof(Hal_t));
		iRval = Hal_Init_Modules(&hHal, iModules);
		hHal.iIsInitialised = 1;
	}
	return iRval;
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_DeInit(int32_t iModules)
{
	int32_t iRval;
	iRval = Hal_Deinit_Modules(&hHal,iModules);
	hHal.iIsInitialised = 0;
	return iRval;
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_EnableModule(int32_t iModule,int32_t iEnable)
{
	int32_t iRetVal =0;
	switch(iModule)
	{
		case eModule_BackLight:
		{
			iRetVal = Cluster_Controller_Hal_Backlight_Enable((uint8_t)iEnable);
		}
		break;
		case eModule_Can:
		{
			//iRetVal = Cluster_Controller_Hal_SocketCan_Enable(iEnable);
		}
		break;
		case eModule_Bt:
		{
			//iRetVal = Cluster_Controller_Hal_Bt_Enable(iEnable);
		}
		break;
		case eModule_Rtc:
		{
			//iRetVal = Cluster_Controller_Hal_Rtc_Enable(iEnable);
		}
		break;
		case eModule_Flash:
		{
			//iRetVal =Cluster_Controller_Hal_Flash_Enable(iEnable);
		}
		break;
		default :
		{
			//
		}
		break;
	}
	return iRetVal;
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_SetReceiveQueueHandle(int32_t iModule,QueueHandle_t qRxMsg)
{
	int32_t iRetVal = BCU_NOK;
	if(qRxMsg != NULL)
	{
		switch(iModule)
		{
			case eModule_Can:
			{
				iRetVal = Cluster_Controller_Hal_Can_SetReceiveQueueHandle(qRxMsg);
			}
			break;
			case eModule_Switch:
			{
				iRetVal = Cluster_Controller_Hal_Switch_SetReceiveQueueHandle(qRxMsg);
			}
			break;
#if BLE_ENABLED
			case eModule_Bt:
			{
				iRetVal = Cluster_Controller_Hal_Bt_SetReceiveQueueHandle(qRxMsg);
			}
#endif
			break;
			case eModule_Rtc:
			{
				iRetVal = Cluster_Controller_Hal_Rtc_SetReceiveQueueHandle(qRxMsg);
			}
			break;		
			case eModule_Adc:
			{
				iRetVal = Cluster_Controller_Hal_Adc_SetReceiveQueueHandle(qRxMsg);
			}
			break;
			default :
			{

			}
			break;			
		}
	}
	return iRetVal;
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_CanSendMessage(sCanMessage_t *pMsg,uint8_t mbIdx)
{
	return Cluster_Controller_Hal_Can_SendMessage(pMsg,mbIdx);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_CanGetMode(void)
{
	return Cluster_Controller_Hal_Can_GetMode();
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_BTSendMessage(uint8_t *pMsg,uint32_t iMsgLen)
{
	return Cluster_Controller_Hal_Bt_SendMessage(pMsg, iMsgLen);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_RtcGetDateTime(sTimeInfo_t * pInfo)
{
	return Cluster_Controller_Hal_Rtc_GetDateTime(pInfo);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_RtcSetDateTime(sTimeInfo_t * pInfo)
{
	return Cluster_Controller_Hal_Rtc_SetDateTime(pInfo);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_RtcUpdateDateTime(void)
{
	return Cluster_Controller_Hal_Rtc_UpdateDateTime();
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_BacklightSetBrightness(uint8_t iValue)
{
	return Cluster_Controller_Hal_Backlight_SetBrightness(iValue);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_BacklightSetBrightnessLevel(uint32_t iLevel)
{
	return Cluster_Controller_Hal_Backlight_SetBrightnessLevel(iLevel);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/

int32_t Cluster_Controller_Hal_FlashWriteData(uint8_t * pBuf, uint32_t iSize,uint32_t iAddr)
{
	return Cluster_Controller_Hal_Flash_WriteData(pBuf,iSize,iAddr);
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_FlashReadData(uint8_t * pBuf, uint32_t iSize,uint32_t iAddr)
{
	return Cluster_Controller_Hal_Flash_ReadData(pBuf,iSize,iAddr);
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_FlashErase(uint32_t iAddr)
{
	return Cluster_Controller_Hal_Flash_Erase(iAddr);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_FlashReadProp(int iParam,uint8_t * pBuf, uint32_t iSize,uint32_t iAddr)
{
	return  Cluster_Controller_Hal_Flash_ReadProp(iParam,pBuf,iSize,iAddr);
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigGetStackSize(uint16_t* pVal)
{
	return Cluster_Controller_Hal_Config_GetStackSize(pVal);
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
uint32_t Cluster_Controller_Hal_ConfigGetFlashAddress(uint32_t iSectorAddr)
{
	 return Cluster_Controller_Hal_Config_GetFlashAddress(iSectorAddr);
}
#if BLE_ENABLED
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigBtGetInterface(uint32_t* pId, uint32_t* pBaudRate)
{
	return Cluster_Controller_Hal_Config_BtGetInterface(pId,pBaudRate);
}
#endif
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigCanGetInterface(int32_t* pId, uint32_t* pBaudRate)
{
	return Cluster_Controller_Hal_Config_CanGetInterface(pId,pBaudRate);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
uint32_t Cluster_Controller_Hal_ConfigGetMaxCanId(void)
{
	return Cluster_Controller_Hal_Config_GetMaxCanId();
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
sCanConfig_t* Cluster_Controller_Hal_ConfigGetCanIdList(void)
{
	return Cluster_Controller_Hal_Config_GetCanIdList();
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigRtcGetInterface(uint32_t * pId, uint32_t * pBaudRate)
{
	return Cluster_Controller_Hal_Config_RtcGetInterface(pId,pBaudRate);
}

/*-----------------------------------------------------------------------------*
* Function	    :											        		   *
* Params	    :					        		                           *
* Return value	:									                           *
* Description	:							                                   *
*-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigRtcGetInterruptConf(int32_t* pVal)
{
	return Cluster_Controller_Hal_Config_RtcGetInterruptConf(pVal);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
uint32_t* Cluster_Controller_Hal_ConfigSwitchGetList(int Id)
{
	return Cluster_Controller_Hal_Config_SwitchGetList(Id);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigBacklightGetInterface(uint8_t* pId, uint32_t* pFreq)
{
	return Cluster_Controller_Hal_Config_BacklightGetInterface(pId,pFreq);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
uint8_t*  Cluster_Controller_Hal_ConfigGetBrightnessMap(void)
{
	return Cluster_Controller_Hal_Config_GetBrightnessMap();
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigGetDefaultBrightnessLevel(uint32_t* pVal)
{
	return Cluster_Controller_Hal_Config_GetDefaultBrightnessLevel(pVal);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_ConfigGetMaxBrightnessLevel(uint32_t* pVal)
{
	return Cluster_Controller_Hal_Config_GetMaxBrightnessLevel(pVal);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
 uint32_t Cluster_Controller_Hal_ConfigFlashInterface(uint32_t * pBase,
													  uint32_t * pPCS0,
													  uint32_t * pClk,
													  uint32_t * pSdo,
													  uint32_t * pSdi)
{
	return Cluster_Controller_Hal_Config_FlashInterface(pBase,pPCS0,pClk,pSdo,pSdi);
}
/*----------------------------------------------------------------------------*
 * Local function 				                         				      *
 *----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/

static int32_t Hal_Init_Modules(Hal_t * pHan ,int32_t iModules)
{
	int32_t iRval = BCU_NOK;

	if(iModules != 0)
	{
		if(pHan->iModulesStatus  == 0)
		{
			Cluster_Controller_Hal_Config_Init();
		}
		
		if (iModules & eModule_BackLight)
		{
			iRval = Cluster_Controller_Hal_Backlight_Init();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus | eModule_BackLight;
			}
			else
			{
				pHan->iModulesStatus = pHan->iModulesStatus & ~eModule_BackLight;
			}
		}
#if BLE_ENABLED
		if (iModules & eModule_Bt)
		{
			iRval = Cluster_Controller_Hal_Bt_Init();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus| eModule_Bt;
			}
			else
			{
				pHan->iModulesStatus = pHan->iModulesStatus & ~eModule_Bt;
			}
		}
#endif
		if (iModules & eModule_Can)
		{
			iRval = Cluster_Controller_Hal_Can_Init();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus| eModule_Can;
			}
			else
			{
				pHan->iModulesStatus = pHan->iModulesStatus & ~eModule_Can;
			}
		}
		
		if (iModules & eModule_Switch)
		{
			iRval = Cluster_Controller_Hal_Switch_Init();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus| eModule_Switch;
			}
			else
			{
				pHan->iModulesStatus = hHal.iModulesStatus & ~eModule_Switch;
			}
		}

		if (iModules & eModule_Rtc)
		{
			iRval = Cluster_Controller_Hal_Rtc_Init();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus| eModule_Rtc;
			}
			else
			{
				pHan->iModulesStatus = hHal.iModulesStatus & ~eModule_Rtc;
			}
		}

		if (iModules & eModule_Flash)
		{
			iRval = Cluster_Controller_Hal_Flash_Init();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus| eModule_Flash;
			}
			else
			{
				pHan->iModulesStatus = hHal.iModulesStatus & ~eModule_Flash;
			}
		}
		if (iModules & eModule_Uds)
		{
			iRval = BCU_OK;
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus| eModule_Uds;
			}
			else
			{
				pHan->iModulesStatus = hHal.iModulesStatus & ~eModule_Uds;
			}
		}
		if (iModules & eModule_Adc)
		{
			iRval = Cluster_Controller_Hal_Adc_Init();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus| eModule_Adc;
			}
			else
			{
				pHan->iModulesStatus = hHal.iModulesStatus & ~eModule_Adc;
			}
		}
	}
	return pHan->iModulesStatus;
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/

static int32_t Hal_Deinit_Modules(Hal_t * pHan, int32_t iModules)
{
	int32_t iRval = BCU_NOK;

	if(pHan->iModulesStatus != 0)
	{
		if (iModules & eModule_BackLight)
		{
			iRval = Cluster_Controller_Hal_Backlight_DeInit();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus & ~eModule_BackLight;
			}
		}
#if BLE_ENABLED
		if (iModules & eModule_Bt)
		{
			iRval = Cluster_Controller_Hal_Bt_DeInit();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus & ~eModule_Bt;
			}
		}
#endif
		if (iModules & eModule_Can)
		{
			//iRval = Cluster_Controller_Hal_Can_DeInit();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus =pHan->iModulesStatus & ~eModule_Can;
			}
		}

		if (iModules & eModule_Switch)
		{
			iRval = Cluster_Controller_Hal_Switch_DeInit();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus & ~eModule_Switch;
			}
		}

		if (iModules & eModule_Rtc)
		{
			iRval = Cluster_Controller_Hal_Rtc_DeInit();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus & ~eModule_Rtc;
			}
		}

		if (iModules & eModule_Flash)
		{
			iRval = Cluster_Controller_Hal_Flash_DeInit();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus & ~eModule_Flash;
			}
		}

		if (iModules & eModule_Uds)
		{
			iRval = BCU_OK;
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus & ~eModule_Uds;
			}
		}
		if (iModules & eModule_Adc)
		{
			iRval = Cluster_Controller_Hal_Adc_DeInit();
			if(iRval == BCU_OK)
			{
				pHan->iModulesStatus = pHan->iModulesStatus & ~eModule_Adc;
			}
		}
		if(pHan->iModulesStatus  == 0)
		{
			Cluster_Controller_Hal_Config_DeInit();
		}
	}
	return pHan->iModulesStatus;

}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_CanReset(bool bIsr)
{
	return Cluster_Controller_Hal_Can_Reset(bIsr);
}

/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
void Cluster_Controller_Hal_FirmwareDownload_Init()
{
	 Cluster_Controller_Hal_Romapi_FirmwareDownload_Init();
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_CanEnable(void)
{
	return Cluster_Controller_Hal_Can_Enable();
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Hal_RtcSetMode(bool bSetMode)
{
	return Cluster_Controller_Hal_Rtc_SetMode(bSetMode);
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Hal_ConfigGetVersion(uint32_t * iSwVersion,uint32_t *iHwVersion)
 {
 	return Cluster_Controller_Hal_Config_GetVersion(iSwVersion ,iHwVersion);
 }
 /*-----------------------------------------------------------------------------*
  * Function	    :											        		   *
  * Params	    :					        		                           *
  * Return value	:									                           *
  * Description	:							                                   *
  *-----------------------------------------------------------------------------*/
 void Cluster_Controller_Hal_ConfigGetSwHwVersion(char * pSwVersion,char * pHwVersion)
 {
	 Cluster_Controller_Hal_Config_GetSwHwVersion(pSwVersion, pHwVersion);
 }
/*-----------------------------------------------------------------------------*
  * Function	    :											        		   *
  * Params	    :					        		                           *
  * Return value	:									                           *
  * Description	:							                                   *
  *-----------------------------------------------------------------------------*/ 
 int32_t Cluster_Controller_HalDisplay_Enable(bool bOnOff)
 {
 	return Cluster_Controller_Hal_Display_Enable(bOnOff);
 }
