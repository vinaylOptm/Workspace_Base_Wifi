/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_manager.c 							   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   *
 *                               						                       *
 *-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------*
 * Include Headers				           	                             	   *
 *-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include "fsl_debug_console.h"
#include "clock_config.h"
#include "cJSON.h"
#include "cluster_common.h"
#include "cluster_controller_hal.h"
#include "cluster_controller_manager_btproc.h"
/*----------------------------------------------------------------------------*
* Macro ,Structure and Enum definitions                        *
*-----------------------------------------------------------------------------*/

#define MAX_QUEUE_MSG_COUNT				50
#define MSG_QUEUE_BUFFER_SIZE 			sizeof(sMessage_t)
#define CACHE_BUF_SIZE					2*MSG_QUEUE_BUFFER_SIZE
#define BLEPROC_LAST_PAC    			"{\"id\":\"end\"}"
#define BLEPROC_LAST_PAC_LEN  		    strlen(BLEPROC_LAST_PAC)
#define  BLE_SPLIT_LEN  				128


typedef struct
{
	int32_t     	iIsInitialised;
	int32_t     	iIsConnected;
	int32_t 		iIsIncomplete;
	int32_t         iIsStarted;
	QueueHandle_t   qRxMsg;
	QueueHandle_t  	qHmiMsg;
	cJSON*          monitor_json;
	char     		sCacheBuf[CACHE_BUF_SIZE];
	char *			pIsEndID;
	TaskHandle_t 	hRxThread;
	SemaphoreHandle_t pBtSema;
}BleProc_t;

/*----------------------------------------------------------------------------*
 * Static and global variable definition	                         		  *
 *----------------------------------------------------------------------------*/
 BleProc_t hBleProc = {0};
/*----------------------------------------------------------------------------*
 * Local function definition	                         				      *
 *----------------------------------------------------------------------------*/
static void BleProc_MsgHandler(void *arg);
static void BleProc_CleanUp(void* arg);
static int32_t BleProc_GetJsonFormat(BleProc_t * pHan, char * pBuf, size_t iLen);
static void BleProc_DataParse(BleProc_t * pHan, char * pBuf, size_t iLen);
static void BleProc_UnpackJson(BleProc_t * pHan ,const char * pJBuf, size_t iSize);
static int32_t BleProc_packJson(BleProc_t * pHan,int32_t iMsgType, void  * pMsg);
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Manager_BTProc_Init					  *
 * Params	    :	QueueHandle_t BtQueueId			        		          *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	  *
 * Description	:	In this method, The initialization, Creating of thread and
 * 					Queue will take place to get the data from HAL and accessi
 * 					-ng the queue id from HMI to send the prepared /parsed da
 * 					-ta.				  									  *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_BTProc_Init(QueueHandle_t BtQueueId)
{
	int32_t iRval = BCU_OK;
	if(hBleProc.iIsInitialised == 0)
	{

		uint16_t iStackSize =0;

		memset(&hBleProc, 0 ,sizeof(hBleProc));
		hBleProc.qHmiMsg = BtQueueId;
		hBleProc.pBtSema = xSemaphoreCreateBinary();

		if(hBleProc.pBtSema != NULL)
		{
			Cluster_Controller_Hal_ConfigGetStackSize(&iStackSize);
			hBleProc.qRxMsg = xQueueCreate(MAX_QUEUE_MSG_COUNT,MSG_QUEUE_BUFFER_SIZE);

			if(hBleProc.qRxMsg != 0)
			{
				if (xTaskCreate(BleProc_MsgHandler,
						"BPROC",
						iStackSize,
						&hBleProc,
						(configMAX_PRIORITIES - 2),
						&hBleProc.hRxThread) == pdPASS)
				{
					xSemaphoreGive(hBleProc.pBtSema);
					iRval = Cluster_Controller_Hal_SetReceiveQueueHandle( eModule_Bt ,
							hBleProc.qRxMsg);
					if(iRval == BCU_OK)
					{
						hBleProc.iIsInitialised = 1;
						PRINTF("\r\nBLEPROC:: BLE Thread create Success \n");
					}
					else
					{
						Cluster_Controller_Manager_BTProc_DeInit();
					}
				}
				else
				{
					iRval = BCU_NOK;
					PRINTF("BLEPROC:Error: BT_receive_Thread create failed \n");
					BleProc_CleanUp(NULL);
				}
			}
			else
			{
				iRval = BCU_NOK;
				PRINTF("BLEPROC:Error: xQueueCreate  failed \n");
			}
		}
		else
		{
			PRINTF("\r\n Error : Ble_Proc xSemaphoreCreateBinary\r\n");
		}
	}
return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Manager_BTProc_DeInit                  *
 * Params	    :	void					       							  *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	  *
 * Description	:	In this method, Deinitialization of BleProc and cancellat
 * 					-ion of created queue and thread.						  *
 *----------------------------------------------------------------------------*/
void Cluster_Controller_Manager_BTProc_DeInit(void)
{
	if(hBleProc.iIsInitialised)
	{
		vTaskSuspend(hBleProc.hRxThread);
		BleProc_CleanUp(NULL);
	}
	memset(&hBleProc, 0, sizeof(BleProc_t));
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Manager_BleProc_Start				  *
 * Params	    :	void					       							  *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	  *
 * Description	:	In this method, Enabling of BLE module will take
 * 					place.								                      *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_BleProc_Start(void)
{
	int32_t iRval = BCU_NOK;
	if(hBleProc.iIsInitialised)
	{
		iRval = Cluster_Controller_Hal_EnableModule(eModule_Bt,1);
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Manager_BleProc_Stop					  *
 * Params	    :	void				       							      *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	  *
 * Description	:   In this method, disabling of BLE module will take
 * 					place.									                  *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_BleProc_Stop(void)
{
	int32_t iRval = BCU_NOK;
	if(hBleProc.iIsInitialised)
	{
		iRval = Cluster_Controller_Hal_EnableModule(eModule_Bt,0);
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :	Bcu_Cluster_Controller_BleProc_SendMessage			      *
 * Params	    :	int iMsgType, void  * pMsg				  			      *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	  *
 * Description	:
 * 												                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_BleProc_SendMessage(int32_t iMsgType, void  * pMsg)
{
	int32_t iRval = BCU_NOK;

	if((hBleProc.iIsInitialised != 0) && (hBleProc.iIsConnected != 0) && (pMsg != NULL))
	{
		iRval = BleProc_packJson(&hBleProc,iMsgType,pMsg);
	}

	return iRval;
}
/*-----------------------------------------------------------------------------*
 * Function	    :	BleProc_MsgHandler										   *
 * Params	    :	void *arg			        		                       *
 * Return value	:	On success return BCU_OK else it will return BCU_NOK	   *
 * Description	:	In this method, The receive data from HAL will take place
 * 					in polling mode, and will send of received data into
 * 					BleProc_DataParse to process the received data.			   *
 *-----------------------------------------------------------------------------*/
static void BleProc_MsgHandler(void *arg)
{
	BleProc_t *  pHan = (BleProc_t *)(arg);

	char sParseBuf[CACHE_BUF_SIZE] = {0};

	int32_t iOffset = 0;
	size_t iSize = 0;

	memset(sParseBuf,0,CACHE_BUF_SIZE);

	while(1)
	{
		taskYIELD();
		if (1 == xQueueReceive(pHan->qRxMsg,&sParseBuf[0],100))
		{
			pHan->iIsConnected = 1;
			iOffset = 0;
			iSize = strlen(&sParseBuf[0]);
			BleProc_DataParse(pHan,&sParseBuf[iOffset],iSize);
			memset(sParseBuf,0,CACHE_BUF_SIZE);
		}
		taskYIELD();
	}

}
/*----------------------------------------------------------------------------*
 * Function	    :	BleProc_CleanUp									          *
 * Params	    :	void* arg			        		                      *
 * Return value	:	void								                      *
 * Description	:	The cancel/delete the Queue which is created during 	  *
 * 					the initialization.							  			  *
 *----------------------------------------------------------------------------*/
static void BleProc_CleanUp(void* arg)
{
    (void)(arg);
	if(hBleProc.qRxMsg != 0)
	{
		vQueueDelete(hBleProc.qRxMsg);
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :	BleProc_DataParse									      *
 * Params	    :	BleProc_t * pHan, char * pBuf, int32_t iLen			      *
 * Return value	:	Void								                      *
 * Description	:	The receiving of data will take place					  *
 * 					until end id is received, And sends the CONNECTED or	  *
 * 					DISCONNECTED strings to Hmi once data received from ble.  *
 *----------------------------------------------------------------------------*/
static void BleProc_DataParse(BleProc_t * pHan, char * pBuf, size_t iLen)
{
	int32_t iRetval = BCU_NOK;
	if ((pBuf != NULL) && (iLen >0))
	{
		int32_t iIsId = (strstr(pBuf, "{\"id\":") != NULL) ? 1 : 0;
		int32_t iIsStatusId = (strstr(pBuf, "CONNECTED") != NULL) ? 1 : 0;

		if(((iIsId == 1) && (iIsStatusId != 1)) || (pHan->iIsIncomplete == 1))
		{
			iRetval = BleProc_GetJsonFormat(pHan,pBuf,iLen);
			if(iRetval == BCU_NOK)
			{
				//PRINTF("\r\n ERROR: BleProc_GetJsonFormat\r\n");
			}
		}
		else
		{
			sMessage_t	 sMsg	=	{0};
			sDeviceStatus_t   sBtStatus = {0};

			if(strstr(pBuf, "CONNECTED"))
			{
				sBtStatus.iId = eBLEStatusInfo;
				sBtStatus.iStatus = 1;
				sMsg.iEventId = eEvent_DeviceStatus;
				memcpy((int8_t *)(sMsg.sData),(int8_t*)(&sBtStatus),sizeof(sDeviceStatus_t));

				xQueueSend(pHan->qHmiMsg, (int8_t*)&sMsg, 100);
				if(iRetval != 1)
				{
					PRINTF("ERROR: xQueueSend\r\n");
				}

				if(iIsStatusId)
				{
					iRetval = BleProc_GetJsonFormat(pHan,&pBuf[9],iLen);

					if(iRetval == BCU_NOK)
					{
						PRINTF("\r\n ERROR: BleProc_GetJsonFormat\r\n");
					}
				}
			}
			else if(strstr(pBuf, "DISCONNECTED"))
			{
				sBtStatus.iId = eBLEStatusInfo;
				sBtStatus.iStatus = 0;
				sMsg.iEventId = eEvent_DeviceStatus;
				memcpy((int8_t *)(sMsg.sData),(int8_t*)(&sBtStatus),sizeof(sDeviceStatus_t));

				xQueueSend(pHan->qHmiMsg, (int8_t*)&sMsg, 100);
				if(iRetval != 1)
				{
					PRINTF("ERROR: xQueueSend\r\n");
				}
			}
			else
			{
				sBtMsg_t sBt = {0};
				sMsg.iEventId = eEvent_BTMessage;
				snprintf(sBt.sMsg,128, "%s",pBuf);
				sBt.bEnable = true;
				memcpy((int8_t *)(sMsg.sData),(int8_t *)(&sBt),sizeof(sBtMsg_t));

				xQueueSend(pHan->qHmiMsg, (int8_t*)&sMsg, 100);
				if(iRetval != 1)
				{
					PRINTF("ERROR: xQueueSend\r\n");
				}
			}
		}
	}
	/*else
	{
		PRINTF("\r\nERROR: In BleProc_DataParse\r\n");
	}*/
}
/*----------------------------------------------------------------------------*
 * Function	    :	BleProc_GetJsonFormat									      *
 * Params	    :	BleProc_t * pHan, char * pBuf, int32_t iLen			      *
 * Return value	:	int32_t								                      *
 * Description	:	 														  *
 *----------------------------------------------------------------------------*/
static int32_t BleProc_GetJsonFormat(BleProc_t * pHan, char * pBuf, size_t iLen)
{
	int32_t iRetval = BCU_OK;

	strncat(pHan->sCacheBuf, pBuf, iLen);

	pHan->iIsIncomplete = 1;

	if((pHan->pIsEndID = strstr(pHan->sCacheBuf, "{\"id\":\"end\"}" )) != NULL)
	{
		char JsonBuf[CACHE_BUF_SIZE];

		memset(JsonBuf,0,CACHE_BUF_SIZE);

		size_t iBufLen = strlen(pHan->sCacheBuf);

		strncpy(JsonBuf, pHan->sCacheBuf, (iBufLen - BLEPROC_LAST_PAC_LEN));

		BleProc_UnpackJson(pHan, &JsonBuf[0], (iBufLen - BLEPROC_LAST_PAC_LEN));

		pHan->iIsIncomplete = 0;

		memset(&(pHan->sCacheBuf[0]), 0, CACHE_BUF_SIZE);
	}
	return iRetval;
}
/*----------------------------------------------------------------------------*
 * Function	    :	BleProc_UnpackJson												 		         *
 * Params	    :	BleProc_t * pHan ,char * pJBuf, int32_t iSize					       							             *       *
 * Return value	:  	void										    		  	  *
 * Description	:	In this method,The data parsing from received data will
 * 					take place and the data will be in form of Json format.							                                      *
 *----------------------------------------------------------------------------*/
static void BleProc_UnpackJson(BleProc_t * pHan ,const char * pJBuf, size_t iSize)
{
	if(pJBuf != NULL && (iSize > 0))
	{
		pHan->monitor_json = cJSON_Parse(pJBuf);
		if (pHan->monitor_json == NULL)
		{
			const char *error_ptr = cJSON_GetErrorPtr();
			if (error_ptr != NULL)
			{
				PRINTF("Error before: %s", error_ptr);
			}
			cJSON_Delete(pHan->monitor_json);
		}
		else
		{
			const cJSON *sJsonId   = NULL;
			sMessage_t	 sMsg	   = {0};

			sJsonId = cJSON_GetObjectItemCaseSensitive(pHan->monitor_json, "id");

			if (cJSON_IsString(sJsonId) && (sJsonId->valuestring != NULL))
			{
				if(strncmp(sJsonId->valuestring, "call", 4) == 0)
				{
					const cJSON *pJsonMode = NULL;
					const cJSON *pJsonName = NULL;
					const cJSON *pJsonPhNo = NULL;
					sCallInfo_t  sCallNoti = {0};

					pJsonMode = cJSON_GetObjectItemCaseSensitive(pHan->monitor_json, "mode");

					if (cJSON_IsString(pJsonMode) && (pJsonMode->valuestring != NULL))
					{
						if(strncmp(pJsonMode->valuestring, "idle", 4) == 0)
						{
							sCallNoti.iMode = eCallIdle;
						}
						else if(strncmp(pJsonMode->valuestring, "in", 2) == 0)
						{
							sCallNoti.iMode = eCallInComing;
						}
						else if(strncmp(pJsonMode->valuestring, "out", 3) == 0)
						{
							sCallNoti.iMode = eCallOutGoing;
						}
						else if(strncmp(pJsonMode->valuestring, "inProgress", 10) == 0)
						{
							sCallNoti.iMode = eCallInProgress;
						}
						else
						{
							if(strncmp(pJsonMode->valuestring, "missed", 6) != 0 )
							{
								PRINTF("\r\n ERROR: BleProc_UnpackJson: iModes\r\n");
							}
						}

						pJsonName = cJSON_GetObjectItemCaseSensitive(pHan->monitor_json, "name");
						pJsonPhNo = cJSON_GetObjectItemCaseSensitive(pHan->monitor_json, "ph");

						if (cJSON_IsString(pJsonName) && (pJsonName->valuestring != NULL))
						{
						    if (strlen(pJsonName->valuestring) > 0)
						    {
						        snprintf(sCallNoti.sMsg, 32, "%s", pJsonName->valuestring);
						    }
						    else if (cJSON_IsString(pJsonPhNo) && (pJsonPhNo->valuestring != NULL))
						    {
						        snprintf(sCallNoti.sMsg, 32, "%s", pJsonPhNo->valuestring);
						    }
						    else
						    {
						        snprintf(sCallNoti.sMsg, 32, "unknown");
						    }
						}
						else if (cJSON_IsString(pJsonPhNo) && (pJsonPhNo->valuestring != NULL))
						{
						    snprintf(sCallNoti.sMsg, 32, "%s", pJsonPhNo->valuestring);
						}
						else
						{
						    snprintf(sCallNoti.sMsg, 32, "unknown");
						}

						PRINTF("\r\nBleProc_UnpackJson : sCallNoti.sMsg: %s", sCallNoti.sMsg);

						if(strncmp(pJsonMode->valuestring, "missed", 6) == 0)
						{
							sBtMsg_t sMissMsg = {0};
							sMissMsg.bEnable = 1;
							//To clear the Incoming/Outgoing call event indication.
							sCallNoti.iMode = eCallIdle;
							memcpy((int8_t *)(sMsg.sData),(int8_t*)(&sCallNoti),sizeof(sCallInfo_t));
							sMsg.iEventId = eEvent_Call;
							xQueueSend(pHan->qHmiMsg, (int8_t*)(&sMsg), 100);

							if(sCallNoti.sMsg[0] != '\0')
							{
								snprintf(sMissMsg.sMsg, 128, "Missed Call: %s",sCallNoti.sMsg);
							}
							else
							{
								snprintf(sMissMsg.sMsg, 128, "Missed Call: %s",sCallNoti.sNum);
							}

							//To send the actual Missed call event.
							memcpy((int8_t *)(sMsg.sData),(int8_t*)(&sMissMsg),sizeof(sBtMsg_t));
							sMsg.iEventId = eEvent_BTMessage;
							xQueueSend(pHan->qHmiMsg, (int8_t*)(&sMsg), 100);
						}
						else
						{
							memcpy((int8_t *)(sMsg.sData),(int8_t*)(&sCallNoti),sizeof(sCallInfo_t));
							sMsg.iEventId = eEvent_Call;
							xQueueSend(pHan->qHmiMsg, (int8_t*)(&sMsg), 100);
						}

					}
				}
				else if(strncmp(sJsonId->valuestring, "map", 3) == 0)
				{
					const cJSON *pJsonDir  = NULL;
					const cJSON *pJsonDist = NULL;
					const cJSON *pJsonMsg  = NULL;
					sTbtNavInfo_t  sTbtNav = {0};

					pJsonDist = cJSON_GetObjectItemCaseSensitive(pHan->monitor_json, "dist");

					if (cJSON_IsNumber(pJsonDist))
					{
						sTbtNav.iDist = pJsonDist->valueint;
						PRINTF("\r\nThe sTbtNav.iDist ;%d",sTbtNav.iDist);
					}

					pJsonDir = cJSON_GetObjectItemCaseSensitive(pHan->monitor_json, "dir");

					if (cJSON_IsNumber(pJsonDir))
					{
						sTbtNav.iDir = pJsonDir->valueint;
						PRINTF("\r\nThe sTbtNav.iDir ;%d",sTbtNav.iDir);
					}

					pJsonMsg = cJSON_GetObjectItemCaseSensitive(pHan->monitor_json, "msg");

					if (cJSON_IsString(pJsonMsg) && (pJsonMsg->valuestring != NULL))
					{
						size_t iLen = strlen(pJsonMsg->valuestring);

						if((iLen < 32) || (pJsonMsg->valuestring[31] == ',') || (pJsonMsg->valuestring[32] == '\0'))
						{
							//pJsonMsg->valuestring[31] = '\n';
							snprintf(sTbtNav.sMsg,32,"%s",pJsonMsg->valuestring);
							PRINTF("\r\nThe sTbtNav.sMsg ;%s",sTbtNav.sMsg);
						}
						else
						{
							int32_t i;
							for(i = 30; i >= 0; i--)
							{
								if(pJsonMsg->valuestring[i] == ',')
								{
									//pJsonMsg->valuestring[i] = '\n';
									break;
								}
							}

							snprintf(sTbtNav.sMsg,(size_t)i+1,"%s",pJsonMsg->valuestring);
							PRINTF("\r\nThe sTbtNav.sMsg ;%s",sTbtNav.sMsg);
						}
					}
					memcpy((int8_t *)(sMsg.sData),(int8_t*)(&sTbtNav),sizeof(sTbtNavInfo_t));
					sMsg.iEventId = eEvent_TurnByTurnNav;
					xQueueSend(pHan->qHmiMsg, (int8_t*)(&sMsg), 200);

				}
				else
				{
					PRINTF("\r\n Error:BleProc_UnpackJson: %s\r\n",sJsonId->valuestring);
				}
			}
			else
			{
				PRINTF("\r\nError:BleProc_UnpackJson: sJsonId\r\n");
			}

			cJSON_Delete(pHan->monitor_json);
		}
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :	BleProc_packJson					                      *
 * Params	    :	BleProc_t * pHan,int32_t iMsgType, void  * pMsg 						      *
 * Return value	:  	int32_t										    		  *
 * Description	:	                                                          *
 *----------------------------------------------------------------------------*/
static int32_t BleProc_packJson(BleProc_t * pHan,int32_t iMsgType, void  * pMsg)
{
	int32_t iRetval = BCU_NOK;

	if (xSemaphoreTake(pHan->pBtSema, portMAX_DELAY) == pdTRUE)
	{
		if((iMsgType > 0) && (pMsg != NULL))
		{
			unsigned char * pJson_str = NULL;

			cJSON *pJsonPack = cJSON_CreateObject();

			switch(iMsgType)
			{
			case eCallResp:
			{
				sCallResp_t * sMsgHan =  (sCallResp_t*)(pMsg);

				cJSON_AddStringToObject(pJsonPack, "Id", "CallResp");

				cJSON_AddNumberToObject(pJsonPack, "Resp", sMsgHan->iResp);

				pJson_str = (unsigned char *)cJSON_Print(pJsonPack);
			}
			break;
			case eVehicleWarning:
			{
				char * pMsgHan =  ((char *)(pMsg));

				cJSON_AddStringToObject(pJsonPack, "Id", "Warning");

				cJSON_AddStringToObject(pJsonPack, "Msg", pMsgHan);

				pJson_str = (unsigned char *)cJSON_Print(pJsonPack);
			}
			break;
			default:
			break;
			}

			if(pJson_str != NULL)
			{
				size_t ilen = strlen((const char *)pJson_str);
				int8_t i, j = 0;

				for (i = 0; i < (int8_t)ilen; i++)
				{
					if ((pJson_str[i] != '\n') && (pJson_str[i] != ' ') && (pJson_str[i] != '\t'))
					{
						pJson_str[j++] = pJson_str[i];
					}
				}

				pJson_str[j] = '\0';

				strncat((char *)pJson_str,(const char *)BLEPROC_LAST_PAC,BLEPROC_LAST_PAC_LEN);

				iRetval = Cluster_Controller_Hal_BTSendMessage(pJson_str, (uint32_t)(strlen((const char *)pJson_str)));

				if(iRetval != BCU_OK)
				{
					PRINTF("\r\nError: Cluster_Controller_Hal_BTSendMessage\r\n");
				} 
			}

			cJSON_free(pJson_str);

			cJSON_Delete(pJsonPack);
		}
		xSemaphoreGive(pHan->pBtSema);
	}
	return iRetval;
}
