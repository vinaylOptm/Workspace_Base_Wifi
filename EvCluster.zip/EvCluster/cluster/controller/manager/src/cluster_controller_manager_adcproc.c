/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_hal_adcproc.c 							   *
 *  version		: 											              	   *
 *  Date		:	30-Nov-2023												   *
 *  Description :  				 										 	   *
 *                               						                       *
 *-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------*
 * Include Headers				           	                             	   *
 *-----------------------------------------------------------------------------*/
/* FreeRTOS kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "semphr.h"
#include "string.h"
#include "fsl_debug_console.h"


#include "cluster_common.h"
#include "cluster_controller_hal.h"
#include "cluster_controller_hal_config.h"
#include "cluster_controller_manager_Adcproc.h"
#include "cluster_controller_manager_systeminfo.h"

#define MAX_QUEUE_MSG_COUNT				10
#define ADC_MSG_QUEUE_BUFFER_SIZE       6
#define MSG_BUFFER_SIZE					sizeof(sAdc_t)
#define MSG_QUEUE_BUFFER_SIZE 			MSG_BUFFER_SIZE + 16
#define ADC_QUEUE_WAITTIME			    500
#define MSG_SEND_DEFAULT_WAIT		    5000



typedef struct
{
	int32_t     		iIsInitialised;
	QueueHandle_t       qRxMsg;
	QueueHandle_t  	    qHmiMsg;
	TaskHandle_t 	    hRxThread;
}AdcProc_t;

char sRxBuf[ADC_MSG_QUEUE_BUFFER_SIZE] = {0};

AdcProc_t hAProc = {0};
static void AdcProc_SendInfo(AdcProc_t *pHan, sAdc_t *pAdcData);
static void AdcProc_MessageHandler(void *arg);
static void AdcProc_CleanUp(void* arg);
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_AdcProc_Init(QueueHandle_t QueueId)
{
	int32_t iRval =BCU_NOK;
	if(hAProc.iIsInitialised == 0)
	{
		uint16_t iStackSize =0;
		Cluster_Controller_Hal_Config_GetStackSize(&iStackSize);

		hAProc.qRxMsg = xQueueCreate(MAX_QUEUE_MSG_COUNT,MSG_QUEUE_BUFFER_SIZE);
		hAProc.qHmiMsg = QueueId;
		if(hAProc.qRxMsg != 0)
		{
			if (xTaskCreate(AdcProc_MessageHandler,
					"AdProc",
					iStackSize,
					&hAProc,
					configMAX_PRIORITIES - 2,
					&hAProc.hRxThread) == pdPASS)
			{
				iRval = Cluster_Controller_Hal_SetReceiveQueueHandle(eModule_Adc ,
						hAProc.qRxMsg);
				if(iRval == BCU_OK)
				{
					hAProc.iIsInitialised = 1;
				}
				else
				{
					Cluster_Controller_Manager_AdcProc_DeInit();
				}
			}
			else
			{
				iRval = BCU_NOK;
				PRINTF("ADCPROC:Error: ADC_receive_Thread create failed \n");
				AdcProc_CleanUp(NULL);
			}
		}
		else
		{
			iRval = BCU_NOK;
			PRINTF("ADCPROC:Error: xQueueCreate  failed \n");
		}
	}
	return (iRval);
}
/*----------------------------------------------------------------------------*
 * Function	    :													 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
void Cluster_Controller_Manager_AdcProc_DeInit(void)
{
	if(hAProc.iIsInitialised)
	{
		vTaskSuspend(hAProc.hRxThread);
		AdcProc_CleanUp(NULL);
	}
	memset(&hAProc, 0, sizeof(AdcProc_t));
}
/*-----------------------------------------------------------------------------*
 * Function	    :											        		   *
 * Params	    :					        		                           *
 * Return value	:									                           *
 * Description	:							                                   *
 *-----------------------------------------------------------------------------*/
static void AdcProc_MessageHandler(void *arg)
{
	AdcProc_t *pHan = (AdcProc_t*)(arg);
	char sBuf[MSG_QUEUE_BUFFER_SIZE];
	sAdc_t adc;

	while (1)
	{
		memset(sBuf, 0, sizeof(sBuf));
		if (xQueueReceive(pHan->qRxMsg, (char*)&sBuf[0], ADC_QUEUE_WAITTIME) == pdPASS)
		{
			memcpy((char*)&adc , &sBuf[0],sizeof(sAdc_t));

			AdcProc_SendInfo(pHan, &adc);
		}
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void AdcProc_CleanUp(void* arg)
{
	(void)(arg);
	if(hAProc.qRxMsg != 0)
	{
		vQueueDelete(hAProc.qRxMsg);
	}
}

/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void AdcProc_SendInfo(AdcProc_t *pHan, sAdc_t *pAdcData)
{
	sMessage_t	  sMsg		= {0};

	sMsg.iEventId = eEvent_Adc;

	memcpy((char *)sMsg.sData, (char *)(pAdcData), sizeof(sAdc_t));

	if((pHan->qHmiMsg != NULL) && (sMsg.iEventId >0))
	{
		xQueueSend(pHan->qHmiMsg, &sMsg, (TickType_t)(MSG_SEND_DEFAULT_WAIT));
	}
}
