/*-----------------------------------------------------------------------------*
 *	OptM Media Solutions Confidential										   *
 *	Copyright (C) OptM Media Solutions Pvt Ltd - All Rights Reserved.	   	   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from OptM Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_controller_manager_wifiproc.c 							   *
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023												   *
 *  Description :  				 										 	   *
 *                               						                       *
 *-----------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------*
 * Include Headers				           	                             	   *
 *-----------------------------------------------------------------------------*/
 
/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "app_config.h"
#include "lwip/tcpip.h"
#include "lwip/sockets.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"
#include "wpl.h"
#include "timers.h"

#include "fsl_debug_console.h"
#include "webconfig.h"
#include <stdio.h>
#include <stdbool.h>
#include "fsl_pxp.h"
#include "jpeglib.h"

#if (defined(ENABLE_TOUCH) && ENABLE_TOUCH == 1)
#include "touch.h"
#endif

#if (defined(ENABLE_SEND_MSG) && ENABLE_SEND_MSG == 1)
#include "msg_send_back.h"
#endif



//#include "cluster_jpeg_data.h"
#include "cluster_controller_hal.h"
#include "cluster_controller_hal_config.h"
#include "cluster_controller_manager_wifiproc.h"
/*----------------------------------------------------------------------------*
 * Macro ,Structure and Enum definitions           				              *
 *-----------------------------------------------------------------------------*/
#define MAX_QUEUE_MSG_COUNT		   10
#define MSG_BUFFER_SIZE			   sizeof(sMessage_t)
#define MSG_QUEUE_BUFFER_SIZE 	   MSG_BUFFER_SIZE + 16
#define WIFI_QUEUE_WAITTIME		   portMAX_DELAY
#define MSG_SEND_DEFAULT_WAIT	   5000

typedef struct
{
	int32_t     		iIsInitialised;
	dc_fb_t				*pgdc;
	TaskHandle_t 	    hRxThread;
	sImageInfo_t		sImage;
	QueueHandle_t       qRxMsg;
	QueueHandle_t  	    qHmiMsg;
}WifiProc_t;


typedef struct sockinfo
{
    int sck;
    int sck_accepted;
    int af;
    int sck_type;
    struct sockaddr_in ipv4;
    struct sockaddr_in6 ipv6;
} sockinfo_t;

enum decode_thread_status {
    DECODE_THREAD_RUNNING = 0,
    DECODE_THREAD_FFMPEG_INIT_FAILED = 1,
    DECODE_THREAD_STOPPED = 2,
};

enum socket_recv_thread_status {
    SOCKET_RECV_THREAD_RUNNING = 0,
    SOCKET_RECV_THREAD_SOCKET_STOPPED = 1,
};

enum thread_command {
    THREAD_START,
    THREAD_STOP,
};

enum app_state {
    APP_WAIT_FOR_CLIENT,
    APP_SOCKET_CONNECTED,
    APP_RUNNING,
    APP_WAIT_THREADS_TO_STOP,
    APP_ERROR,
};

struct ring_buffer_mgr {
    uint8_t *write_ptr;
    uint8_t *read_ptr;
    size_t pending_read_size;
    bool flush_needed;
    SemaphoreHandle_t ring_buffer_mutex;
};

struct thread_control {
    int status;
    enum thread_command command;
};

/*----------------------------------------------------------------------------*
 * Static and global variable definition	                         		  *
 *----------------------------------------------------------------------------*/
static WifiProc_t hWfProc = {0};
/*******************************************************************************
 * Variables
 ******************************************************************************/
#define READ_SIZE (256 << 10)
static uint8_t __attribute__((section("OCRAMDataAccess"))) sJpegBuf[(1024 << 10)];


#if DEMO_USE_XRGB8888
typedef uint32_t pixel_t;
#else
typedef uint16_t pixel_t;
#endif


#if PXP_RENDERING
#define IMG_POS_X 0U
#define IMG_POS_Y 0U
#define IMG_BPP   DEMO_BUFFER_BYTE_PER_PIXEL
static pxp_output_buffer_config_t sPxpOutBufConfig;
static pxp_ps_buffer_config_t sPxpPsBufConfig;

AT_NONCACHEABLE_SECTION_ALIGN(static pixel_t s_BufferLcd[2][DEMO_PANEL_HEIGHT][DEMO_PANEL_WIDTH], 32);
static dc_fb_info_t fbInfo;
static uint8_t curLcdBufferIdx = 1U;
#endif

static volatile bool s_newFrameShown = false;

TaskHandle_t * hDecodeTask;
TaskHandle_t * hSocketRxTask;
struct thread_control sSocketRecvControl = {0};
struct thread_control sDecodeControl = {0};

struct ring_buffer_mgr sRingBugMgr = {
										.pending_read_size = 0,
										.read_ptr = sJpegBuf,
										.write_ptr = sJpegBuf,
										.flush_needed = false,
									};

/*----------------------------------------------------------------------------*
 * Local function definition	                         				      *
 *----------------------------------------------------------------------------*/

static void WifiProc_CleanUp(void* arg);
static uint32_t WifiProc_AccessPoint_Clean();
static void WifiProc_WP_InitHandler(void *arg);
static void __attribute__((section("CodeQuickAccess"))) decode_display_task(void *arg);
//static void WifiProc_SendImageInfo(WifiProc_t* pHan);

#if 0
static uint32_t WifiProc_GetTime(void);
static void WifiProc_PxPInit(WifiProc_t* pHan);
static inline void WifiProc_Image_Render(void);
static void WifiProc_RingBuffer_Reset(struct ring_buffer_mgr *buffer_mgr);
static void WifiProc_RingBuffer_Callback(void *param, void *switchOffBuffer);

static void WifiProc_PrintIP(void);
static void WifiProc_Link_StatusChangeCallback(bool linkState);
static int WifiProc_Image_Decode(uint8_t *data_buffer, size_t data_size,
								 uint8_t *buf_ptr[3],uint32_t *jpeg_size);
static void WifiProc_WP_Socket_StateHandler(void *arg);
static uint32_t WifiProc_AccessPoint_Start();
static const char* __attribute__((section("CodeQuickAccess"))) memmem_backward(const char* data, size_t data_len, const char* mark, size_t mark_len);
static int32_t WifiProc_Receiver_Set_Timeout(int sck);
static int WifiProc_IPToSocketAddr(const char *ip_str,const int port,
								   struct sockaddr_in *ipv4,
								   struct sockaddr_in6 *ipv6);
static void __attribute__((section("CodeQuickAccess"))) WifiProc_WP_Socket_RecvHandler(void *arg);
#endif
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Manager_WifiProc_Init									        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_WifiProc_Init(QueueHandle_t QueueId)
{
	int32_t iRval =BCU_NOK;
	if(hWfProc.iIsInitialised == 0)
	{
		uint16_t iStackSize =0;
		memset(&hWfProc, 0 ,sizeof(hWfProc));
		hWfProc.qHmiMsg = QueueId;

		Cluster_Controller_Hal_Config_GetStackSize(&iStackSize);

		hWfProc.qRxMsg = xQueueCreate(MAX_QUEUE_MSG_COUNT,MSG_QUEUE_BUFFER_SIZE);

		if(hWfProc.qRxMsg != 0)
		{
			if (xTaskCreate(WifiProc_WP_InitHandler,
					        "WifiProc_WP_InitHandler",
							iStackSize,
							&hWfProc,
							configMAX_PRIORITIES - 2,
							&hWfProc.hRxThread) == pdPASS)
			{

				iRval = BCU_OK;
				if(iRval == BCU_OK)
				{
					hWfProc.iIsInitialised = 1;
					PRINTF("\r\nWifiProc:: Wifi_receive_Thread create Success \n");
				}
				else
				{
					Cluster_Controller_Manager_WifiProc_DeInit();
				}
			}
			else
			{
				iRval = BCU_NOK;
				PRINTF("WifiProc:Error: Wifi_receive_Thread create failed \n");
				WifiProc_CleanUp(NULL);
			}
		}
		else
		{
			iRval = BCU_NOK;
			PRINTF("WifiProc:Error: xQueueCreate  failed \n");
		}
	}
	return (iRval);
}
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Manager_WifiProc_DeInit												 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
void Cluster_Controller_Manager_WifiProc_DeInit(void)
{
	if(hWfProc.iIsInitialised)
	{
		vTaskSuspend(hWfProc.hRxThread);
		WifiProc_CleanUp(NULL);
	}
	memset(&hWfProc, 0, sizeof(WifiProc_t));
}

/*----------------------------------------------------------------------------*
 * Function	    :	WifiProc_CleanUp									        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void WifiProc_CleanUp(void* arg)
{
	(void)(arg);
	if(hWfProc.qRxMsg != 0)
	{
		vQueueDelete(hWfProc.qRxMsg);
	}
}
/*----------------------------------------------------------------------------*
 * Function	    :	decode_display_task									        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
static void __attribute__((section("CodeQuickAccess"))) decode_display_task(void *arg)
{
	(void)arg;
    struct thread_control *decode_thread_control = &sDecodeControl;
#if (PXP_RENDERING == 1)
    struct ring_buffer_mgr *buffer_mgr = &sRingBugMgr;
    uint32_t parse_size, bytes_used;
    uint8_t * read_ptr;
    size_t    pending_read_size;
    static uint8_t *parse_ptr[3] = {&parse_y[0], &parse_u[0], &parse_v[0]};

#if (defined(ENABLE_SEND_MSG) && ENABLE_SEND_MSG == 1)
    uint32_t frame_cnt = 0;
    uint32_t time_cnt = 0;
    uint32_t frame_index = 0;
#endif

    AT_NONCACHEABLE_SECTION_ALIGN(static uint8_t parse_y[RECV_IMG_HEIGHT * RECV_IMG_WIDTH],     FRAME_BUFFER_ALIGN);
    AT_NONCACHEABLE_SECTION_ALIGN(static uint8_t parse_u[RECV_IMG_HEIGHT * RECV_IMG_WIDTH / 4], FRAME_BUFFER_ALIGN);
    AT_NONCACHEABLE_SECTION_ALIGN(static uint8_t parse_v[RECV_IMG_HEIGHT * RECV_IMG_WIDTH / 4], FRAME_BUFFER_ALIGN);
#endif

    PRINTF("\r\nDecoding thread started \r\n");
    decode_thread_control->command = THREAD_START;

    while (decode_thread_control->command == THREAD_START)
    {
#if (PXP_RENDERING == 1)
        if (buffer_mgr->pending_read_size == 0) {
            vTaskDelay(pdMS_TO_TICKS(5));
            continue;
        }

        xSemaphoreTake(buffer_mgr->ring_buffer_mutex, portMAX_DELAY);
        read_ptr          = buffer_mgr->read_ptr;
        pending_read_size = buffer_mgr->pending_read_size;
        xSemaphoreGive(buffer_mgr->ring_buffer_mutex);

        bytes_used = WifiProc_Image_Decode(buffer_mgr->read_ptr,
        								  buffer_mgr->pending_read_size,
										  parse_ptr,
										  &parse_size);

        if (parse_size == 0) {
            vTaskDelay(pdMS_TO_TICKS(5));
            continue;
        }

        if (bytes_used > 0)
        {
#if (PXP_RENDERING == 1)
			sPxpPsBufConfig.bufferAddr  = (uint32_t)parse_ptr[0];
			sPxpPsBufConfig.bufferAddrU = (uint32_t)parse_ptr[1];
			sPxpPsBufConfig.bufferAddrV = (uint32_t)parse_ptr[2];

			WifiProc_Image_Render();
#else
		    hWfProc.sImage.pImage  = (uint8_t *)(&parse_ptr[0]);
		    hWfProc.sImage.iHeight = RECV_IMG_HEIGHT;
		    hWfProc.sImage.iWidth  = RECV_IMG_WIDTH;
		    hWfProc.sImage.bEnable = true;
		    WifiProc_SendImageInfo(&hWfProc);
#endif

#if (defined(ENABLE_SEND_MSG) && ENABLE_SEND_MSG == 1)
            if (bytes_used + 4 <= buffer_mgr->pending_read_size && *(uint8_t *)(buffer_mgr->read_ptr + bytes_used) != 0xFF)
            {
                frame_index = *(uint32_t *)(buffer_mgr->read_ptr + bytes_used);
                bytes_used += 4; // frame index
            }

            frame_cnt += 1;
            if (frame_cnt >= MSG_SEND_FRAME_COUNT)
            {
                msg_send_back_frame(frame_cnt, frame_index, WifiProc_GetTime() - time_cnt);
                frame_cnt = 0;
                time_cnt  = WifiProc_GetTime();
            }
#endif

            xSemaphoreTake(buffer_mgr->ring_buffer_mutex, portMAX_DELAY);

            buffer_mgr->read_ptr += bytes_used;
            buffer_mgr->pending_read_size -= bytes_used;

            if (buffer_mgr->read_ptr >= sJpegBuf + ARRAY_SIZE(sJpegBuf)) {
                buffer_mgr->read_ptr = sJpegBuf;
            }

            if (buffer_mgr->flush_needed &&
                buffer_mgr->pending_read_size < ARRAY_SIZE(sJpegBuf) / 2) {
                buffer_mgr->flush_needed = false;
            }
        }

        xSemaphoreGive(buffer_mgr->ring_buffer_mutex);
        if (!buffer_mgr->flush_needed) {
            vTaskDelay(pdMS_TO_TICKS(10));
        }
#endif

#if 0
	    hWfProc.sImage.pImage  = &jpeg_data_0[0];
	    hWfProc.sImage.iHeight = RECV_IMG_HEIGHT;
	    hWfProc.sImage.iWidth  = RECV_IMG_WIDTH;
	    hWfProc.sImage.bEnable = true;
	    WifiProc_SendImageInfo(&hWfProc);
#endif
        vTaskDelay(pdMS_TO_TICKS(10000));
    }

    PRINTF("\r\nhWfProc.sImage.iHeight:%d\thWfProc.sImage.iWidth:%d\t \r\n",hWfProc.sImage.iHeight,hWfProc.sImage.iWidth);
    PRINTF("Decoding thread terminated \r\n");
    decode_thread_control->status = DECODE_THREAD_STOPPED;

    vTaskDelete(NULL);
}

/*----------------------------------------------------------------------------*
 * Function	    :	WifiProc_WP_InitHandler												 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static void WifiProc_WP_InitHandler(void *pArg)
{
	(void)pArg;
#if (PXP_RENDERING == 1)
	WifiProc_t * pHan = (WifiProc_t *)pArg;
    WifiProc_PxPInit(pHan);
#endif

#if (WIFI_AP_ENABLE == 1)
    uint32_t result = 1;
    /* Initialize Wi-Fi board */
    WC_DEBUG("[i] Initializing Wi-Fi connection... \r\n");

    result = WPL_Init();
    if (result != WPLRET_SUCCESS)
    {
        PRINTF("[!] WPL Init failed: %d\r\n", (uint32_t)result);
        __BKPT(0);
    }

    result = WPL_Start(WifiProc_Link_StatusChangeCallback);
    if (result != WPLRET_SUCCESS)
    {
        PRINTF("[!] WPL Start failed %d\r\n", (uint32_t)result);
        __BKPT(0);
    }

    WC_DEBUG("[i] Successfully initialized Wi-Fi module\r\n");

#if (defined(WIFI_MODE) && WIFI_MODE == WIFI_MODE_AP)
    /* Main Loop */
    WifiProc_AccessPoint_Start();

#elif (defined(WIFI_MODE) && WIFI_MODE == WIFI_MODE_STA)
    WPL_AddNetwork(WIFI_HOST_SSID, WIFI_HOST_PWD, WIFI_HOST_LABEL);
    PRINTF("Joining: %s\r\n", WIFI_HOST_SSID);

    result = WPL_Join(WIFI_HOST_LABEL);
    if (result != WPLRET_SUCCESS)
    {
        PRINTF("Failed to join network!\r\n");
        if (WPL_RemoveNetwork(WIFI_HOST_LABEL) != WPLRET_SUCCESS)
        {
            PRINTF("Failed to remove network!\r\n");
            __BKPT(0);
        }
    }
    PRINTF("Network joined\r\n");
#endif

    WifiProc_PrintIP();


    if (xTaskCreate(WifiProc_WP_Socket_StateHandler, "WifiProc_WP_Socket_StateHandler", 1024, NULL, configMAX_PRIORITIES - 2, NULL) != pdPASS)
#else
    if (xTaskCreate(decode_display_task, "decode_display_task", 1024, NULL, configMAX_PRIORITIES - 2, NULL) != pdPASS)
#endif
    {
        PRINTF("decode_display_task creation not success!\r\n");
        while (1);
    }
    /* Suspend here until its time to stop the AP */
    vTaskSuspend(NULL);
    WifiProc_AccessPoint_Clean();

}

/*----------------------------------------------------------------------------*
 * Function	    :	WifiProc_AccessPoint_Clean												 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static uint32_t WifiProc_AccessPoint_Clean()
{
    /* Give time for reply message to reach the web interface before destorying the conection */
    vTaskDelay(10000 / portTICK_PERIOD_MS);

    WC_DEBUG("[i] Stopping AP!\r\n");
    if (WPL_Stop_AP() != WPLRET_SUCCESS)
    {
        PRINTF("Error while stopping AP\r\n");
        while (1)
            __BKPT(0);
    }
    return 0;
}
#if 0
/*----------------------------------------------------------------------------*
 * Function	    :	WifiProc_SendImageInfo												 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static void WifiProc_SendImageInfo(WifiProc_t* pHan)
{
	sMessage_t	  sMsg		= {0};
	sMsg.iEventId 			= eEvent_Image;

	memcpy((char *)sMsg.sData,(char*)(&(pHan->sImage)),sizeof(sImageInfo_t));

	if((pHan->qHmiMsg !=NULL) && (sMsg.iEventId >0))
	{
		xQueueSend(pHan->qHmiMsg, &sMsg, (TickType_t)(MSG_SEND_DEFAULT_WAIT));
	}
}
#endif
#if (PXP_RENDERING == 1)
/*----------------------------------------------------------------------------*
 * Function	    :	Cluster_Controller_Manager_WifiProc_GetDisplayParams												 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_WifiProc_GetDisplayParams(dc_fb_t *pg_dc)
{
	int32_t iRval = BCU_OK;
	if(hWfProc.iIsInitialised)
	{
		hWfProc.pgdc = pg_dc;
	}
	return iRval;
}
/*----------------------------------------------------------------------------*
 * Function	    :													 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_WifiProc_LCDIF_Init(dc_fb_t *pGdc)
{
	pGdc->ops->getLayerDefaultConfig(pGdc, 1, &fbInfo);

	pGdc->ops->disableLayer(pGdc, 1);
    fbInfo.pixelFormat = kVIDEO_PixelFormatRGB565,

    fbInfo.width       = DEMO_PANEL_HALF_WIDTH;
    fbInfo.height      = SCALED_IMG_HEIGHT;		//DEMO_BUFFER_HEIGHT;
    fbInfo.startX      = DEMO_PANEL_HALF_WIDTH;	//0
    fbInfo.startY      = 0;						//0
    fbInfo.strideBytes = DEMO_PANEL_HALF_WIDTH * 2;	//

    pGdc->ops->setLayerConfig(pGdc,1, &fbInfo);

    pGdc->ops->setCallback(pGdc, 1, WifiProc_RingBuffer_Callback, NULL);

    s_newFrameShown = false;
    status_t status = pGdc->ops->setFrameBuffer(pGdc, 1, (void *)s_BufferLcd[curLcdBufferIdx]);

    s_newFrameShown = true;
    //g_dc->ops->enableLayer(pGdc, 1);
    hWfProc.pgdc = pGdc;
    return 0;
}
#endif //#if PXP_RENDERING

#if (WIFI_AP_ENABLE == 1)
/*----------------------------------------------------------------------------*
 * Function	    :	WifiProc_Link_StatusChangeCallback									        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
/* Link lost callback */
static void WifiProc_Link_StatusChangeCallback(bool linkState)
{
    if (linkState == false)
    {
        PRINTF("-------- LINK LOST --------\r\n");
    }
    else
    {
        PRINTF("-------- LINK REESTABLISHED --------\r\n");
    }
}
#endif

#if (PXP_RENDERING == 1)
/*----------------------------------------------------------------------------*
 * Function	    :	WifiProc_GetTime									        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
uint32_t WifiProc_GetTime(void)
{
    return (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS);
}

/*----------------------------------------------------------------------------*
 * Function	    :	WifiProc_RingBuffer_Callback												 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static void WifiProc_RingBuffer_Callback(void *param, void *switchOffBuffer)
{
	(void)(param);
	(void)(switchOffBuffer);
    s_newFrameShown = true;
}

#if (PXP_RENDERING == 1)
/*----------------------------------------------------------------------------*
 * Function	    :	WifiProc_PxPInit												 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static void WifiProc_PxPInit(WifiProc_t* pHan)
{
	//Enables the PXP peripheral clock, and resets the PXP registers
    PXP_Init(PXP);

    /* PS configure. */
    sPxpPsBufConfig.pixelFormat = kPXP_PsPixelFormatYVU420;
    sPxpPsBufConfig.pitchBytes = RECV_IMG_WIDTH;
    sPxpPsBufConfig.swapByte = false;
    sPxpPsBufConfig.bufferAddr = 0U;
    sPxpPsBufConfig.bufferAddrU = 0U;
    sPxpPsBufConfig.bufferAddrV = 0U;
    PXP_SetProcessSurfaceBackGroundColor(PXP, 0U);
    PXP_SetProcessSurfaceBufferConfig(PXP, &sPxpPsBufConfig);
    /* Disable AS. */
    PXP_SetAlphaSurfacePosition(PXP, 0xFFFFU, 0xFFFFU, 0U, 0U);

    /* Output config. */
#if DEMO_USE_XRGB8888
    sPxpOutBufConfig.pixelFormat = kPXP_OutputPixelFormatARGB8888;
#else
    sPxpOutBufConfig.pixelFormat = kPXP_OutputPixelFormatRGB565;
#endif
    sPxpOutBufConfig.interlacedMode = kPXP_OutputProgressive;
    sPxpOutBufConfig.buffer0Addr = (uint32_t)s_BufferLcd[0];
    sPxpOutBufConfig.buffer1Addr = 0U;
    sPxpOutBufConfig.pitchBytes = SCALED_IMG_WIDTH * IMG_BPP;

#if (defined(DISPLAY_ROTATE) && DISPLAY_ROTATE == 1)
    sPxpOutBufConfig.width = SCALED_IMG_HEIGHT;
    sPxpOutBufConfig.height = SCALED_IMG_WIDTH;
#else
    sPxpOutBufConfig.width =  SCALED_IMG_WIDTH;
    sPxpOutBufConfig.height = SCALED_IMG_HEIGHT;
#endif
    PXP_SetOutputBufferConfig(PXP, &sPxpOutBufConfig);

    PXP_SetCsc1Mode(PXP, kPXP_Csc1YCbCr2RGB);
    PXP_EnableCsc1(PXP, true);
}
#endif

/*----------------------------------------------------------------------------*
 * Function	    :													 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static inline void WifiProc_Image_Render(void)
{
    static uint32_t startTime = 0, time, n = 0;
    /*
    * Wait for the new set frame buffer active, so that the older frame
    * buffer is inactive, then PXP could output to the older frame buffer.
    */
    while (s_newFrameShown == false)
    {
        vTaskDelay(pdMS_TO_TICKS(5));
    }

    /* Switch to the other LCD buffer. */
    curLcdBufferIdx ^= 1U;
    // Start to convert next frame via PXP
    PXP_SetProcessSurfaceBufferConfig(PXP, &sPxpPsBufConfig);
    PXP_SetProcessSurfaceScaler(PXP, RECV_IMG_WIDTH, RECV_IMG_HEIGHT, SCALED_IMG_WIDTH, SCALED_IMG_HEIGHT);
    PXP_SetProcessSurfacePosition(PXP,
                                  IMG_POS_X,
                                  IMG_POS_Y,
                                  IMG_POS_X + SCALED_IMG_WIDTH  - 1U,
                                  IMG_POS_Y + SCALED_IMG_HEIGHT - 1U);
    sPxpOutBufConfig.buffer0Addr = (uint32_t)s_BufferLcd[curLcdBufferIdx];


    PXP_SetOutputBufferConfig(PXP, &sPxpOutBufConfig);
    PXP_Start(PXP);

    /* Wait for process complete. */
    while (!(kPXP_CompleteFlag & PXP_GetStatusFlags(PXP)))
    {
        vTaskDelay(pdMS_TO_TICKS(5));
    }
    PXP_ClearStatusFlags(PXP, kPXP_CompleteFlag);

    s_newFrameShown = false;
    g_dc.ops->setFrameBuffer(&g_dc, 0, (void *)s_BufferLcd[curLcdBufferIdx]);	

    if (n++ >= 29)
    {
        time = WifiProc_GetTime() - startTime;
        if (startTime != 0)
            PRINTF("%d frames in %d seconds: %d fps\r\n", n, time / 1000, n * 1000 / time);
        n         = 0;
        startTime = WifiProc_GetTime();
    }
}

#endif
#if 0
/*----------------------------------------------------------------------------*
 * Function	    :													 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static int WifiProc_IPToSocketAddr(const char *ip_str,
                               const int port,
                               struct sockaddr_in *ipv4,
                               struct sockaddr_in6 *ipv6)
{
    int ret;
    int af;

    if (port > 0xffff)
    {
        PRINTF("Port '%d' is not lower than 65536\r\n", port);
        return -1;
    }
    if (port <= 0)
    {
        PRINTF("Port '%d' is not greater than 0\r\n", port);
        return -1;
    }

    /* Convert IP */
    af = AF_INET;
    memset(ipv4, 0, sizeof(struct sockaddr_in));
    ipv4->sin_len    = sizeof(struct sockaddr_in);
    ipv4->sin_family = (sa_family_t)af;
    ipv4->sin_port   = (u16_t)htons(port);
    ret              = inet_pton(af, ip_str, &ipv4->sin_addr.s_addr);
    if (ret != 1)
    {
        /* Address is not valid IPv4 address. Lets try treat it as IPv6 */

        af = AF_INET6;
        memset(ipv6, 0, sizeof(struct sockaddr_in6));
        ipv6->sin6_len      = sizeof(struct sockaddr_in6);
        ipv6->sin6_family   = (sa_family_t)af;
        ipv6->sin6_port     = (u16_t)htons(port);
        ipv6->sin6_scope_id = netif_get_index(netif_default);

        LOCK_TCPIP_CORE();
        ret = inet_pton(af, ip_str, &ipv6->sin6_addr.s6_addr);
        UNLOCK_TCPIP_CORE();

        if (ret != 1)
        {
            PRINTF("'%s' is not valid IPv4 nor IPv6 address.\r\n", ip_str);
            return -1;
        }

#if LWIP_IPV6_SCOPES == 1
        /* IPv6 string can contain scope id, check if any netif matches */
        ip6_addr_t addr;
        LOCK_TCPIP_CORE();
        ip6addr_aton(ip_str, &addr);
        UNLOCK_TCPIP_CORE();
        if (addr.zone > 0)
        {
            ipv6->sin6_scope_id = addr.zone;
        }
#endif
    }

    return af;
}

/*----------------------------------------------------------------------------*
 * Function	    :													 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static int32_t WifiProc_Receiver_Set_Timeout(int sck)
{
    struct timeval timeout = {.tv_usec = RECV_TIMEOUT_MS * 1000, .tv_sec = RECV_TIMEOUT_SEC};

    int err = lwip_setsockopt(sck, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    if (err)
    {
        PRINTF("\r\nSetting socket receive timeout failed (%d).\r\n", err);
    }

    return err;
}
/*----------------------------------------------------------------------------*
 * Function	    :													 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static const char* __attribute__((section("CodeQuickAccess"))) memmem_backward(const char* data, size_t data_len, const char* mark, size_t mark_len)
{
    const char* cur;
    const char* last;
    if (data == 0 || mark == 0 || data_len <= 0 || mark_len <= 0)
    {
        return NULL;
    }
    last =  data + data_len - mark_len;
    for (cur = last; cur >= data; --cur) {
        if (cur[0] == mark[0] && memcmp(cur, mark, mark_len) == 0) {
            return cur;
        }
    }
    return NULL;
}

/*----------------------------------------------------------------------------*
 * Function	    :													 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static int WifiProc_Image_Decode(uint8_t *data_buffer,
								 size_t data_size,
                          	  	 uint8_t *buf_ptr[3],
								 uint32_t *jpeg_size)
{
    /* This struct contains the JPEG decompression parameters */
    static struct jpeg_decompress_struct cinfo;
    /* This struct represents a JPEG error handler */
    static struct jpeg_error_mgr jerr;

    size_t byte_used = 0;


    /* Find EOI marker */
    uint8_t *frame_end = (uint8_t *)memmem_backward(data_buffer, data_size, "\xFF\xD9", 2);
    // uint8_t *frame_end = (uint8_t *)memmem(data_buffer, data_size, "\xFF\xD9", 2);
    if (!frame_end)
	{
    	PRINTF("\r\nERROR: End Frame markers not found!\n\r");
        return 0;
    }

    /* Find SOI marker */
    uint8_t *frame_start = (uint8_t *)memmem_backward(data_buffer, frame_end - data_buffer + 1, "\xFF\xD8", 2);
    if (!frame_start) {
    	PRINTF("\r\nERROR: Start Frame markers not found!\n\r");
        return 0;
    }

    frame_end += 2;
    if (frame_end > frame_start) {
        *jpeg_size = frame_end - frame_start;
    }
    else
    {
        *jpeg_size = 0;
        return 0;
    }

    // Step 1: allocate and initialize JPEG decompression object
    cinfo.err = jpeg_std_error(&jerr);

    // Step 2: Initialize the JPEG decompression object
    jpeg_create_decompress(&cinfo);
    jpeg_mem_src(&cinfo, frame_start, *jpeg_size);

    // Step 3: read image parameters with jpeg_read_header()
    jpeg_read_header(&cinfo, true);

    cinfo.raw_data_out = true;
    cinfo.do_fancy_upsampling = false;
#if (PXP_RENDERING == 1)
    cinfo.out_color_space = JCS_YCbCr;
#else
    cinfo.out_color_space = JCS_RGB;
#endif
    cinfo.dct_method = JDCT_FASTEST;
    cinfo.do_block_smoothing = false;
    cinfo.dither_mode = JDITHER_NONE;
    cinfo.scale_num = 1;
    cinfo.scale_denom = 1;

    // Step 5: start decompressor
    jpeg_start_decompress(&cinfo);


#if (PXP_RENDERING == 1)
    uint32_t row_once = 16;

    // Decode JPEG Image
    static uint8_t * y[RECV_IMG_HEIGHT];
    static uint8_t * u[RECV_IMG_HEIGHT/2];
    static uint8_t * v[RECV_IMG_HEIGHT/2];  /* Output row buffer */
    static bool init_flag = false;
    uint8_t ** img_ptr[3] = {y, u, v};  /* Output row buffer */

    if (!init_flag)
    {
        for (uint32_t i = 0; i < RECV_IMG_HEIGHT; i++)
        {
            y[i] = buf_ptr[0] + RECV_IMG_WIDTH * i;
        }
        for (uint32_t i = 0; i < RECV_IMG_HEIGHT; i+=2)
        {
            u[i/2] = buf_ptr[1] + RECV_IMG_WIDTH * i/4;
            v[i/2] = buf_ptr[2] + RECV_IMG_WIDTH * i/4;
        }
        init_flag = true;
    }

    for (uint32_t i = 0; i < cinfo.output_height; i += 16)
    {
        if (cinfo.output_height < i + 16)
		{
            row_once = cinfo.output_height - i;
		}
        jpeg_read_raw_data(&cinfo, img_ptr, row_once);

        img_ptr[0] = img_ptr[0] + 16;
        img_ptr[1] = img_ptr[1] + 8;
        img_ptr[2] = img_ptr[2] + 8;
    }
#else
//    JSAMPARRAY buffer = NULL;     /* Output row buffer */
//    int row_stride = row_stride = cinfo->output_width * cinfo->output_components;

//  buffer = (*cinfo->mem->alloc_sarray)((j_common_ptr)cinfo, JPOOL_IMAGE, row_stride, 1);
    while (cinfo.output_scanline < cinfo.output_height)
    {
      /* jpeg_read_scanlines expects an array of pointers to scanlines.
       * Here the array is only one element long, but you could ask for
       * more than one scanline at a time if that's more convenient.
       */
      (void)jpeg_read_scanlines(&cinfo, (JSAMPARRAY)(&buf_ptr[0]),1);
    }
#endif
    // Step 6: Finish decompression
    jpeg_finish_decompress(&cinfo);
    // Step 7: Release JPEG decompression object
    jpeg_destroy_decompress(&cinfo);

    byte_used = (size_t)(frame_end > data_buffer ? frame_end - data_buffer : 0);
    return byte_used;
}

/*----------------------------------------------------------------------------*
 * Function	    :	WifiProc_WP_Socket_StateHandler												 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static void WifiProc_WP_Socket_StateHandler(void *arg)
{
	(void)(arg);
    int  ret;
    sockinfo_t sockinfo;
    struct sockaddr_in client_addr;
    uint32_t client_addr_len;

    enum app_state cur_state, next_state;

    sRingBugMgr.ring_buffer_mutex = xSemaphoreCreateMutex();

    sockinfo.af = WifiProc_IPToSocketAddr("::", RECV_PORT, &sockinfo.ipv4, &sockinfo.ipv6);

    if (sockinfo.af < 0)
    {
        while(1);
    }
    sockinfo.sck_type = SOCK_STREAM;

    PRINTF("\r\n Creating new socket.\r\n");
    sockinfo.sck = socket(sockinfo.af, sockinfo.sck_type, 0);
    if (sockinfo.sck < 0)
    {
        PRINTF("Socket creation failed. (%d)\r\n", sockinfo.sck);
        while(1);
    }

    if (sockinfo.af == AF_INET)
    {
        ret = bind(sockinfo.sck, (struct sockaddr *)&sockinfo.ipv4, sizeof(sockinfo.ipv4));
    }
    else
    {
        ret = bind(sockinfo.sck, (struct sockaddr *)&sockinfo.ipv6, sizeof(sockinfo.ipv6));
    }

    if (ret < 0)
    {
        PRINTF("bind() failed (errno=%d)\r\n", errno);
        while(1);
    }

    ret = listen(sockinfo.sck, MAX_CLIENT_QUEUE);
    if (ret < 0) {
        PRINTF("ERR: Failed to listen on TCP socket: %d", errno);
        close(sockinfo.sck);
        while(1);
    }
    cur_state = APP_WAIT_FOR_CLIENT;
    next_state = APP_WAIT_FOR_CLIENT;

    while (1) {
        switch (cur_state) {
        case APP_WAIT_FOR_CLIENT:
            PRINTF("TCP: Waiting for client...\n");

            client_addr_len = sizeof(client_addr);
            sockinfo.sck_accepted = accept(sockinfo.sck, (struct sockaddr *)&client_addr, &client_addr_len);

            if (sockinfo.sck_accepted >= 0)
            {
                PRINTF("TCP: Accepted connection\n");
                client_addr.sin_port = htons(RECV_PORT);
                next_state = APP_SOCKET_CONNECTED;
            }
            break;
        case APP_SOCKET_CONNECTED:
            sSocketRecvControl.command = THREAD_START;
            sDecodeControl.command = THREAD_START;
            sSocketRecvControl.status = SOCKET_RECV_THREAD_RUNNING;
            sDecodeControl.status = DECODE_THREAD_RUNNING;
            /* Creation of socket recv task */
            if (hSocketRxTask == NULL && xTaskCreate(WifiProc_WP_Socket_RecvHandler, "WifiProc_WP_Socket_RecvHandler", 2048, &sockinfo.sck_accepted, configMAX_PRIORITIES - 1, hSocketRxTask) !=
                pdPASS)
            {
                PRINTF("WifiProc_WP_Socket_RecvHandler creation failed!\r\n");
                while (1)
                    ;
            }
            /* Creation of parse decode stream */
            if (hDecodeTask == NULL && xTaskCreate(decode_display_task, "decode_display_task", 16 * 1024, NULL, configMAX_PRIORITIES - 2, hDecodeTask) !=
                pdPASS)
            {
                PRINTF("decode_display_task creation failed!\r\n");
                while (1)
                    ;
            }
            next_state = APP_RUNNING;
            break;
        case APP_RUNNING:
            if (sDecodeControl.status == DECODE_THREAD_FFMPEG_INIT_FAILED) {
                next_state = APP_ERROR;
            } else if (sSocketRecvControl.status != SOCKET_RECV_THREAD_RUNNING ||
                   sDecodeControl.status != DECODE_THREAD_RUNNING
#if (defined(ENABLE_TOUCH) && ENABLE_TOUCH == 1)
                   || touch_get_connection_status() == false
#endif
                   ) {
                sSocketRecvControl.command = THREAD_STOP;
                sDecodeControl.command = THREAD_STOP;
                shutdown(sockinfo.sck_accepted, SHUT_RDWR);
                close(sockinfo.sck_accepted);
                next_state = APP_WAIT_THREADS_TO_STOP;
            } else {
                vTaskDelay(pdMS_TO_TICKS(1000));
            }
            break;
        case APP_WAIT_THREADS_TO_STOP:
            if (sSocketRecvControl.status == SOCKET_RECV_THREAD_SOCKET_STOPPED &&
                sDecodeControl.status == DECODE_THREAD_STOPPED) {
                WifiProc_RingBuffer_Reset(&sRingBugMgr);
                next_state = APP_WAIT_FOR_CLIENT;
            } else {
                vTaskDelay(pdMS_TO_TICKS(1000));
            }
            break;
        case APP_ERROR:
            shutdown(sockinfo.sck_accepted, SHUT_RDWR);
            close(sockinfo.sck_accepted);
            sSocketRecvControl.command = THREAD_STOP;
            sDecodeControl.command = THREAD_STOP;
            vTaskDelay(portMAX_DELAY);
            break;
        default:
        	break;
        }
        cur_state = next_state;
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}
/*----------------------------------------------------------------------------*
 * Function	    :													 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static uint32_t WifiProc_AccessPoint_Start()
{
    uint32_t result;

    /* Start the access point */
    PRINTF("Starting Access Point: SSID: %s, Chnl: %d\r\n", WIFI_SSID, WIFI_AP_CHANNEL);
    result = WPL_Start_AP(WIFI_SSID, WIFI_PASSWORD, WIFI_AP_CHANNEL);

    if (result != WPLRET_SUCCESS)
    {
        PRINTF("[!] Failed to start access point\r\n");
        while (1)
            __BKPT(0);
    }

    char ip[16];
    WPL_GetIP(ip, 0);
    PRINTF(" Now join that network on your device and connect to this IP: %s\r\n", ip);

    return 0;
}

/*----------------------------------------------------------------------------*
 * Function	    :	WifiProc_PrintIP											 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static void WifiProc_PrintIP(void)
{
    struct netif *netif_;
    NETIF_FOREACH(netif_)
    {
        PRINTF("************************************************\r\n");
        PRINTF(" Interface name   : %s%d\r\n", netif_->name, netif_->num);
        PRINTF(" IPv4 Address     : %s\r\n", ip4addr_ntoa(netif_ip4_addr(netif_)));
        PRINTF(" IPv4 Subnet mask : %s\r\n", ip4addr_ntoa(netif_ip4_netmask(netif_)));
        PRINTF(" IPv4 Gateway     : %s\r\n", ip4addr_ntoa(netif_ip4_gw(netif_)));
        for (int i = 0; i < LWIP_IPV6_NUM_ADDRESSES; i++)
        {
            const char *str_ip = "-";
            if (ip6_addr_isvalid(netif_ip6_addr_state(netif_, i)))
            {
                str_ip = ip6addr_ntoa(netif_ip6_addr(netif_, i));
            }
            PRINTF(" IPv6 Address%d    : %s\r\n", i, str_ip);
        }
        PRINTF("************************************************\r\n");
    }
}
#endif


#if 0
/*----------------------------------------------------------------------------*
 * Function	    :													 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static void __attribute__((section("CodeQuickAccess"))) WifiProc_WP_Socket_RecvHandler(void *arg)
{
    struct ring_buffer_mgr *buffer_mgr =&sRingBugMgr;
    struct thread_control *recv_thread_control = &sSocketRecvControl;
    int *sock_client = (int *) arg;

    int32_t err;

    uint32_t rem_space, recv_size;
    int32_t recv_len;

    PRINTF("Socket receiving started \r\n");

    err = WifiProc_Receiver_Set_Timeout(*sock_client);
    if (err)
    {
        PRINTF("Socket set receive timeout failed, receiving thread terminated \r\n");
        recv_thread_control->status = SOCKET_RECV_THREAD_SOCKET_STOPPED;
        vTaskDelete(NULL);
    }

    while (1) {
        xSemaphoreTake(buffer_mgr->ring_buffer_mutex, portMAX_DELAY);

        if(buffer_mgr->write_ptr >= buffer_mgr->read_ptr)
        {
        	rem_space = (ARRAY_SIZE(sJpegBuf) -(buffer_mgr->write_ptr - sJpegBuf));
        }
        else
        {
        	rem_space = buffer_mgr->read_ptr - buffer_mgr->write_ptr;
        }
        if (rem_space < READ_SIZE)
        {
            memmove(sJpegBuf, buffer_mgr->read_ptr,buffer_mgr->pending_read_size);

            buffer_mgr->write_ptr = sJpegBuf + buffer_mgr->pending_read_size;
            buffer_mgr->read_ptr = sJpegBuf;
        }

        if (buffer_mgr->pending_read_size + READ_SIZE > ARRAY_SIZE(sJpegBuf))
        {
            PRINTF("\r\nERR: Ring buffer is full,Wait for flush! \r\n");

            buffer_mgr->flush_needed = true;
            xSemaphoreGive(buffer_mgr->ring_buffer_mutex);

            while (buffer_mgr->flush_needed)
            {
                vTaskDelay(pdMS_TO_TICKS(100));
            }
            continue;
        }

        /* Receive video buffer from client */
        if(buffer_mgr->write_ptr >= buffer_mgr->read_ptr)
        {
        	recv_size = (uint32_t)(MIN(READ_SIZE,ARRAY_SIZE(sJpegBuf) -(buffer_mgr->write_ptr - sJpegBuf)));
        }
        else
        {
        	recv_size = (uint32_t)( MIN(READ_SIZE, buffer_mgr->read_ptr - buffer_mgr->write_ptr));
        }

        xSemaphoreGive(buffer_mgr->ring_buffer_mutex);
        recv_len = (int32_t)(read(*sock_client, buffer_mgr->write_ptr, recv_size));
        if (recv_len <= 0) {
            PRINTF("ERR: Connection break, stop receiving thread\r\n");
            break;
        }

        xSemaphoreTake(buffer_mgr->ring_buffer_mutex, portMAX_DELAY);

        buffer_mgr->write_ptr += recv_len;
        buffer_mgr->pending_read_size += recv_len;
        if (buffer_mgr->write_ptr >= sJpegBuf + ARRAY_SIZE(sJpegBuf))
        {
            buffer_mgr->write_ptr = sJpegBuf;
        }

        xSemaphoreGive(buffer_mgr->ring_buffer_mutex);
        vTaskDelay(pdMS_TO_TICKS(5));
    }

    PRINTF("Socket receiving thread terminated \r\n");
    recv_thread_control->status = SOCKET_RECV_THREAD_SOCKET_STOPPED;
    vTaskDelete(NULL);
}
/*----------------------------------------------------------------------------*
 * Function	    :													 		  *
 * Params	    :						       							      *
 *			    :   			         		                              *
 * Return value	:														  	  *
 * Description	:								                              *
 *----------------------------------------------------------------------------*/
static void WifiProc_RingBuffer_Reset(struct ring_buffer_mgr *buffer_mgr)
{
    buffer_mgr->flush_needed = false;
    buffer_mgr->pending_read_size = 0;
    buffer_mgr->read_ptr = sJpegBuf;
    buffer_mgr->write_ptr = sJpegBuf;
}
#endif
