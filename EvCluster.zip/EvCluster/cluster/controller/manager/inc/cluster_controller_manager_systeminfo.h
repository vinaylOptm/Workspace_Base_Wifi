/*
 * cluster_controller_manager_systeminfo.h
 *
 *  Created on: Jul 6, 2023
 *      Author: Admin
 */

#ifndef CLUSTER_CONTROLLER_MANAGER_SYSTEMINFO_H_
#define CLUSTER_CONTROLLER_MANAGER_SYSTEMINFO_H_


 /*-----------------------------------------------------------------------------*
  * Function	    : 	Cluster_Controller_Manager_SystemInfo_Init				*
  * Params	        :	void			        		                        *
  * Return value	:	On success return BCU_OK else return BCU_NOK            *
  * Description  	:	In this function initializes the systeminfo and creates
  * 					xSemaphoreCreateBinary to synchronize the read and write
  * 					operation. And Read the data from secondary flash for re
  * 					-ference						                        *
  *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_Init(void);
/*-----------------------------------------------------------------------------*
  * Function	    : 	Cluster_Controller_Manager_SystemInfo_DeInit			*
  * Params	        :	void			        		                        *
  * Return value	:	On success return BCU_OK else return BCU_NOK            *
  * Description  	:	In this function Deinitializes the systeminfo and delete
  * 					vSemaphore which is created in initialization.			*
  *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_DeInit(void);
/*-----------------------------------------------------------------------------*
  * Function	    : 	Cluster_Controller_Manager_SystemInfo_UpdateInfo     	*
  * Params	        :	sClusterInfo_t* pInfo and int32_t iValue			       	*
  * Return value	:	On success return BCU_OK else return BCU_NOK            *
  * Description  	:	In this function,Write the data to secondary flash(Nvm) *
  *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_UpdateInfo(sClusterInfo_t* pInfo, uint32_t iMode);
/*-----------------------------------------------------------------------------*
 * Function	    : 	Cluster_Controller_Manager_SystemInfo_GetInfo   			*
 * Params	        :	sClusterInfo_t* pInfo		       						*
 * Return value	:	On success return BCU_OK else return BCU_NOK            *
 * Description  	:	In this function,Read the data to secondary flash(Nvm)  *
 *-----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_GetInfo(sClusterInfo_t* pInfo);
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_GetVehicleSpecInfo(sDeviceInfo_t * pInfo);
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_UpdateProductInfo(uint64_t iInfo, uint32_t iSectorAddress);
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_SetSystemInfo(sClusterInfo_t* pInfo,uint32_t iMode);
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_SetVehicleSpecInfo(void * pInfo, int32_t iParam);
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t  Cluster_Controller_Manager_SystemInfo_GetDTCInfo(uint8_t * pDtcInfo);
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_GetCache(void);
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_UpdateChargeStatus(sChargeAlert_t *pCharge);
/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
int32_t Cluster_Controller_Manager_SystemInfo_GetChargeStatus(sChargeAlert_t *pCharge);

#endif /* CLUSTER_CONTROLLER_MANAGER_SYSTEMINFO_H_ */
