#ifndef CLUSTER_CONTROLLER_MANAGER_BTPROC_H_
#define CLUSTER_CONTROLLER_MANAGER_BTPROC_H_


#ifdef __cplusplus
 extern "C" {
#endif

/*-----------------------------------------------------------------------------*
 *	Optm Media Solutions Confidential										   *
 *	Copyright (C) Optm Media Solutions Pvt. Ltd - All Rights Reserved	   	   *
 *																			   *
 *  Dissemination of this information or reproduction or redistribution of 	   *
 *  this material is  strictly forbidden unless prior written permission is	   *
 *  obtained from Optm Media Solutions Pvt Ltd								   *
 *	File Name	:	cluster_hal_spi.h
 *  version		: 											              	   *
 *  Date		:	03-Mar-2023
 *  Description :  				 										 	   *
 *                               						                       *
 *																			   *
 *-----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------*
 * Include Headers				           	                             	  *
 *----------------------------------------------------------------------------*/



/*----------------------------------------------------------------------------*
 * Structure and enum definations				                              *
 *----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*
 * Methods                      				                              *
 *----------------------------------------------------------------------------*/


 /*----------------------------------------------------------------------------*
  * Function	    :Cluster_Controller_Manager_BTProc_Init					   *
  * Params	    	:QueueHandle_t BtQueueId			        		       *
  * Return value	:On success return BCU_OK else it will return BCU_NOK	   *
  * Description		:In this method, The initialization, Creating of thread and
  * 				 Queue will take place to get the data from HAL and accessi
  * 				-ng the queue id from HMI to send the prepared /parsed da-ta.
  * 								  									       *
  *----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Manager_BTProc_Init(QueueHandle_t BtQueueId);
 /*----------------------------------------------------------------------------*
  * Function	    :	Cluster_Controller_Manager_BTProc_DeInit               *
  * Params	        :	void					       						   *
  * Return value	:	On success return BCU_OK else it will return BCU_NOK   *
  * Description	    :	In this method, Deinitialization of BleProc and cance
  * 					-llation of created queue and thread.				   *
  *----------------------------------------------------------------------------*/
 void Cluster_Controller_Manager_BTProc_DeInit(void);
 /*----------------------------------------------------------------------------*
  * Function	    :										        	   	      *
  * Params	    :				        		                          	  *
  * Return value	:									                          *
  * Description	:									                          *
  *----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Manager_BleProc_SendMessage(int32_t iMsgType, void  * pMsg);

 /*----------------------------------------------------------------------------*
  * Function	    :	Cluster_Controller_Manager_BleProc_Start			   *
  * Params	        :	void					       						   *
  * Return value	:	On success return BCU_OK else it will return BCU_NOK   *
  * Description   	:	In this method, Enabling of BLE module will take
  * 					place.								                   *
  *----------------------------------------------------------------------------*/
  int32_t Cluster_Controller_Manager_BleProc_Start(void);
  /*----------------------------------------------------------------------------*
   * Function	    :	Cluster_Controller_Manager_BleProc_Stop					*
   * Params	        :	void				       							    *
   * Return value	:	On success return BCU_OK else it will return BCU_NOK    *
   * Description	:   In this method, disabling of BLE module will take
   * 					place.									                *
   *----------------------------------------------------------------------------*/
  int32_t Cluster_Controller_Manager_BleProc_Stop(void);

#ifdef __cplusplus
}
#endif


#endif /* CLUSTER_CONTROLLER_MANAGER_BTPROC_H_ */
