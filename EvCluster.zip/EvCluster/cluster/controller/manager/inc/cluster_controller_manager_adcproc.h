/*
 * cluster_controller_manager_adcproc.h
 *
 *  Created on: Nov 30, 2023
 *      Author: Admin
 */

#ifndef CONTROLLER_MANAGER_INC_CLUSTER_CONTROLLER_MANAGER_ADCPROC_H_
#define CONTROLLER_MANAGER_INC_CLUSTER_CONTROLLER_MANAGER_ADCPROC_H_



/*----------------------------------------------------------------------------*
 * Structure and enum definations				                              *
 *----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*
 * Methods                      				                              *
 *----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------*
 * Function	    :										        	   	      *
 * Params	    :				        		                          	  *
 * Return value	:									                          *
 * Description	:									                          *
 *----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Manager_AdcProc_Init(QueueHandle_t QueueId);
 /*----------------------------------------------------------------------------*
  * Function	    :										        	   	      *
  * Params	    :				        		                          	  *
  * Return value	:									                          *
  * Description	:									                          *
  *----------------------------------------------------------------------------*/
 void Cluster_Controller_Manager_AdcProc_DeInit(void);
 /*----------------------------------------------------------------------------*
  * Function	    :										        	   	      *
  * Params	    :				        		                          	  *
  * Return value	:									                          *
  * Description	:									                          *
  *----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Manager_AdcProc_StartTest(QueueHandle_t hUartQueueId);
 /*----------------------------------------------------------------------------*
  * Function	    :										        	   	      *
  * Params	    :				        		                          	  *
  * Return value	:									                          *
  * Description	:									                          *
  *----------------------------------------------------------------------------*/
 int32_t Cluster_Controller_Manager_AdcProc_StopTest(void);


#endif /* CONTROLLER_MANAGER_INC_CLUSTER_CONTROLLER_MANAGER_ADCPROC_H_ */
