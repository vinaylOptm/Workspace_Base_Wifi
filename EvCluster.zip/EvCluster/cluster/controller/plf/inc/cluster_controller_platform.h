#ifndef CLUSTER_CONTROLLER_PLATFORM_H_
#define CLUSTER_CONTROLLER_PLATFORM_H_

namespace ControllerPlatform {
	void Start();
} // ControllerPlatform

#endif /* CLUSTER_CONTROLLER_PLATFORM_H_ */
